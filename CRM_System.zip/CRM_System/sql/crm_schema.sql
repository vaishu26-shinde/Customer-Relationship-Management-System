-- ============================================================
--  CRM SYSTEM DATABASE SCHEMA
--  Run this file in MySQL before starting the application
-- ============================================================

CREATE DATABASE IF NOT EXISTS crm_system;
USE crm_system;

-- CUSTOMERS TABLE
CREATE TABLE IF NOT EXISTS customers (
    customer_id     INT AUTO_INCREMENT PRIMARY KEY,
    first_name      VARCHAR(50)  NOT NULL,
    last_name       VARCHAR(50)  NOT NULL,
    email           VARCHAR(100) UNIQUE NOT NULL,
    phone           VARCHAR(20),
    company         VARCHAR(100),
    address         TEXT,
    city            VARCHAR(60),
    state           VARCHAR(60),
    country         VARCHAR(60) DEFAULT 'India',
    customer_type   ENUM('Individual','Corporate','VIP') DEFAULT 'Individual',
    status          ENUM('Active','Inactive','Prospect') DEFAULT 'Active',
    notes           TEXT,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- INTERACTIONS TABLE
CREATE TABLE IF NOT EXISTS interactions (
    interaction_id  INT AUTO_INCREMENT PRIMARY KEY,
    customer_id     INT NOT NULL,
    interaction_type ENUM('Call','Email','Meeting','Chat','Support','Follow-up') NOT NULL,
    subject         VARCHAR(200) NOT NULL,
    description     TEXT,
    outcome         VARCHAR(200),
    interaction_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    next_follow_up  DATE,
    created_by      VARCHAR(100) DEFAULT 'Admin',
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE CASCADE
);

-- SERVICE HISTORY TABLE
CREATE TABLE IF NOT EXISTS service_history (
    service_id      INT AUTO_INCREMENT PRIMARY KEY,
    customer_id     INT NOT NULL,
    service_type    VARCHAR(100) NOT NULL,
    description     TEXT,
    status          ENUM('Pending','In Progress','Resolved','Closed','Cancelled') DEFAULT 'Pending',
    priority        ENUM('Low','Medium','High','Critical') DEFAULT 'Medium',
    ticket_number   VARCHAR(20) UNIQUE,
    assigned_to     VARCHAR(100),
    resolution      TEXT,
    service_date    DATETIME DEFAULT CURRENT_TIMESTAMP,
    resolved_date   DATETIME,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE CASCADE
);

-- PRODUCTS / DEALS TABLE
CREATE TABLE IF NOT EXISTS deals (
    deal_id         INT AUTO_INCREMENT PRIMARY KEY,
    customer_id     INT NOT NULL,
    deal_name       VARCHAR(200) NOT NULL,
    value           DECIMAL(15,2),
    stage           ENUM('Lead','Qualified','Proposal','Negotiation','Won','Lost') DEFAULT 'Lead',
    close_date      DATE,
    probability     INT DEFAULT 0,
    notes           TEXT,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE CASCADE
);

-- SAMPLE DATA
INSERT INTO customers (first_name, last_name, email, phone, company, city, state, customer_type, status) VALUES
('Rahul',    'Sharma',   'rahul.sharma@techcorp.in',  '9876543210', 'TechCorp India',    'Pune',      'Maharashtra', 'Corporate',   'Active'),
('Priya',    'Patel',    'priya.patel@gmail.com',     '9765432109', NULL,                'Mumbai',    'Maharashtra', 'Individual',  'Active'),
('Amit',     'Verma',    'amit.verma@startupxyz.com', '9654321098', 'StartupXYZ',        'Bangalore', 'Karnataka',   'Corporate',   'Active'),
('Sneha',    'Joshi',    'sneha.joshi@gmail.com',     '9543210987', NULL,                'Delhi',     'Delhi',       'VIP',         'Active'),
('Vikram',   'Singh',    'vikram.singh@enterprise.in','9432109876', 'Enterprise Ltd',    'Chennai',   'Tamil Nadu',  'Corporate',   'Inactive'),
('Anjali',   'Mehta',    'anjali.mehta@outlook.com',  '9321098765', NULL,                'Hyderabad', 'Telangana',   'Individual',  'Prospect');

INSERT INTO interactions (customer_id, interaction_type, subject, description, outcome) VALUES
(1, 'Call',    'Initial Sales Call',       'Discussed product requirements and pricing.', 'Interested, sending proposal'),
(1, 'Email',   'Proposal Sent',            'Sent detailed proposal for Enterprise package.', 'Awaiting response'),
(2, 'Meeting', 'Product Demo',             'Live demo of CRM features.', 'Very positive, considering purchase'),
(3, 'Support', 'Technical Issue',          'Login problem reported by client.', 'Resolved in 2 hours'),
(4, 'Call',    'Renewal Discussion',       'Annual subscription renewal call.', 'Renewed for 2 years'),
(5, 'Email',   'Reactivation Offer',       'Sent special offer for inactive account.', 'No response yet');

INSERT INTO service_history (customer_id, service_type, description, status, priority, ticket_number, assigned_to) VALUES
(1, 'Technical Support', 'API integration assistance needed.',     'Resolved',     'High',     'TKT-0001', 'Dev Team'),
(2, 'Billing Issue',     'Double charge on last invoice.',          'Resolved',     'Critical', 'TKT-0002', 'Billing Team'),
(3, 'Feature Request',   'Request for custom reporting module.',    'In Progress',  'Medium',   'TKT-0003', 'Product Team'),
(4, 'Account Setup',     'New user onboarding and configuration.',  'Closed',       'Low',      'TKT-0004', 'Support Team'),
(5, 'Data Migration',    'Migrate data from legacy system.',        'Pending',      'High',     'TKT-0005', 'Dev Team');

INSERT INTO deals (customer_id, deal_name, value, stage, probability, close_date) VALUES
(1, 'Enterprise CRM Package', 250000.00, 'Proposal',     60,  '2026-04-30'),
(2, 'Individual Pro Plan',     12000.00, 'Negotiation',  80,  '2026-03-31'),
(3, 'Startup Bundle Deal',     45000.00, 'Qualified',    40,  '2026-05-15'),
(4, 'VIP Annual Contract',    180000.00, 'Won',         100,  '2026-01-15'),
(6, 'New Client Prospect',     30000.00, 'Lead',         20,  '2026-06-01');
