@echo off
echo ============================================
echo   CRM Pro - Compiling and Running...
echo ============================================

set JAVA_SRC=src
set OUT_DIR=out
set LIB=lib\mysql-connector-java-8.0.33.jar

if not exist %OUT_DIR% mkdir %OUT_DIR%

echo [1/2] Compiling Java sources...
javac -cp "%LIB%" -d %OUT_DIR% -sourcepath %JAVA_SRC% %JAVA_SRC%\com\crm\Main.java

if %errorlevel% neq 0 (
    echo [ERROR] Compilation failed. Check errors above.
    pause
    exit /b 1
)

echo [2/2] Launching CRM Pro...
java -cp "%OUT_DIR%;%LIB%" com.crm.Main

pause
