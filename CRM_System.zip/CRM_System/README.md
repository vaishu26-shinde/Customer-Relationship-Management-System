# ◈ CRM Pro — Customer Relationship Management System
### BTech Project | Java + MySQL | Swing GUI

---

## 📋 Project Overview

A fully-featured **Customer Relationship Management (CRM)** desktop application built with:
- **Java Swing** — Rich, dark-themed GUI
- **MySQL** — Relational database backend
- **JDBC** — Java Database Connectivity
- **Design Patterns** — DAO, Singleton, MVC

---

## 🗂️ Project Structure

```
CRM_System/
├── src/
│   └── com/crm/
│       ├── Main.java                    ← Entry point (run this)
│       ├── model/
│       │   ├── Customer.java
│       │   ├── Interaction.java
│       │   ├── ServiceTicket.java
│       │   └── Deal.java
│       ├── dao/
│       │   ├── CustomerDAO.java
│       │   ├── InteractionDAO.java
│       │   ├── ServiceTicketDAO.java
│       │   └── DealDAO.java
│       ├── ui/
│       │   ├── MainWindow.java
│       │   ├── DashboardPanel.java
│       │   ├── CustomerPanel.java
│       │   ├── InteractionPanel.java
│       │   ├── ServicePanel.java
│       │   └── DealsPanel.java
│       └── util/
│           ├── DatabaseConnection.java
│           └── UITheme.java
├── sql/
│   └── crm_schema.sql                  ← Run this in MySQL first
├── lib/
│   └── mysql-connector-java-8.x.x.jar  ← Add this manually
└── README.md
```

---

## ⚙️ Setup Instructions

### Step 1 — Install Prerequisites
- **Java JDK 17+** → https://www.oracle.com/java/technologies/downloads/
- **MySQL 8.0+** → https://dev.mysql.com/downloads/mysql/
- **MySQL Connector/J** → https://dev.mysql.com/downloads/connector/j/
  - Download the `.jar` file and place it in the `/lib` folder

### Step 2 — Set Up the Database
1. Open **MySQL Workbench** or MySQL command line
2. Run the schema file:
   ```sql
   SOURCE /path/to/CRM_System/sql/crm_schema.sql;
   ```
   Or paste the contents of `crm_schema.sql` and execute it.

### Step 3 — Configure Database Connection
Open `src/com/crm/util/DatabaseConnection.java` and update:
```java
private static final String USER     = "root";          // your MySQL username
private static final String PASSWORD = "your_password"; // your MySQL password
```

### Step 4 — Open in IDE

#### IntelliJ IDEA (Recommended)
1. File → Open → Select `CRM_System` folder
2. Right-click `lib/mysql-connector-java.jar` → Add as Library
3. Run `src/com/crm/Main.java`

#### Eclipse
1. File → Import → Existing Java Project → Select `CRM_System`
2. Right-click project → Build Path → Add External JARs → select `mysql-connector-java.jar`
3. Run `Main.java`

#### NetBeans
1. File → Open Project → Select `CRM_System`
2. Right-click Libraries → Add JAR/Folder → select `mysql-connector-java.jar`
3. Run `Main.java`

### Step 5 — Compile & Run (Command Line)
```bash
# From CRM_System directory
javac -cp "lib/mysql-connector-java-8.x.x.jar" -d out -sourcepath src src/com/crm/Main.java
java  -cp "out;lib/mysql-connector-java-8.x.x.jar" com.crm.Main
# On Linux/Mac use : instead of ; in classpath
```

---

## 🎯 Features

| Module | Features |
|--------|----------|
| **Dashboard** | KPI cards, live stats, pipeline value, quick tips |
| **Customers** | Add, Edit, Delete, Search, View Details |
| **Interactions** | Log Calls, Emails, Meetings, Follow-ups |
| **Service Desk** | Create Tickets, Update Status, Priority tracking |
| **Deals** | Pipeline management, Stage tracking, Revenue |

---

## 🗃️ Database Tables

| Table | Purpose |
|-------|---------|
| `customers` | Core customer profiles |
| `interactions` | Every touchpoint (call, email, meeting) |
| `service_history` | Support tickets and resolutions |
| `deals` | Sales pipeline and deal stages |

---

## 🎨 UI Theme
- Dark navy color scheme (`#0D111E` background)
- Electric blue accent (`#388BFF`)
- Color-coded status badges (Green=Active, Red=Danger, Yellow=Pending)
- Striped table rows with hover effects
- Smooth sidebar navigation with active state indicator

---

## 📐 Design Patterns Used

| Pattern | Where Used |
|---------|-----------|
| **Singleton** | `DatabaseConnection` — single DB connection |
| **DAO (Data Access Object)** | All `*DAO.java` classes |
| **MVC (Model-View-Controller)** | model/ + ui/ + dao/ separation |
| **Factory Method** | `UITheme` button/component factories |

---

## 📊 Sample Data
The SQL script inserts 6 sample customers, interactions, tickets, and deals so the app looks populated immediately on first run.

---

## 🧪 Testing the App
1. Launch → Splash screen → Dashboard loads with live stats
2. Go to **Customers** → Try Add/Edit/Delete/Search
3. Go to **Interactions** → Log a new call or email
4. Go to **Service Desk** → Create a ticket, then update its status
5. Go to **Deals** → Add a deal, change its stage

---

## 👨‍💻 Technologies
- **Language:** Java 17
- **GUI:** Java Swing (javax.swing)
- **Database:** MySQL 8.0
- **Connectivity:** JDBC (mysql-connector-java)
- **IDE:** IntelliJ IDEA / Eclipse / NetBeans

---

*BTech Final Year Project — CRM System | 2026*
