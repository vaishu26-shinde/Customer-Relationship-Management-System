package com.crm.dao;

import com.crm.model.Customer;
import com.crm.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CustomerDAO {

    private Connection getConn() {
        return DatabaseConnection.getInstance().getConnection();
    }

    // ── CREATE ──────────────────────────────────────────
    public boolean addCustomer(Customer c) {
        String sql = "INSERT INTO customers (first_name,last_name,email,phone,company,address,city,state,country,customer_type,status,notes) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
        try (PreparedStatement ps = getConn().prepareStatement(sql)) {
            ps.setString(1, c.getFirstName());  ps.setString(2, c.getLastName());
            ps.setString(3, c.getEmail());       ps.setString(4, c.getPhone());
            ps.setString(5, c.getCompany());     ps.setString(6, c.getAddress());
            ps.setString(7, c.getCity());        ps.setString(8, c.getState());
            ps.setString(9, c.getCountry());     ps.setString(10, c.getCustomerType());
            ps.setString(11, c.getStatus());     ps.setString(12, c.getNotes());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    // ── READ ALL ────────────────────────────────────────
    public List<Customer> getAllCustomers() {
        List<Customer> list = new ArrayList<>();
        String sql = "SELECT * FROM customers ORDER BY created_at DESC";
        try (Statement st = getConn().createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    // ── READ BY ID ──────────────────────────────────────
    public Customer getCustomerById(int id) {
        String sql = "SELECT * FROM customers WHERE customer_id=?";
        try (PreparedStatement ps = getConn().prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapRow(rs);
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    // ── SEARCH ──────────────────────────────────────────
    public List<Customer> searchCustomers(String keyword) {
        List<Customer> list = new ArrayList<>();
        String sql = "SELECT * FROM customers WHERE first_name LIKE ? OR last_name LIKE ? OR email LIKE ? OR company LIKE ? OR phone LIKE ? ORDER BY first_name";
        String k = "%" + keyword + "%";
        try (PreparedStatement ps = getConn().prepareStatement(sql)) {
            for (int i = 1; i <= 5; i++) ps.setString(i, k);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    // ── UPDATE ──────────────────────────────────────────
    public boolean updateCustomer(Customer c) {
        String sql = "UPDATE customers SET first_name=?,last_name=?,email=?,phone=?,company=?,address=?,city=?,state=?,country=?,customer_type=?,status=?,notes=? WHERE customer_id=?";
        try (PreparedStatement ps = getConn().prepareStatement(sql)) {
            ps.setString(1, c.getFirstName());  ps.setString(2, c.getLastName());
            ps.setString(3, c.getEmail());       ps.setString(4, c.getPhone());
            ps.setString(5, c.getCompany());     ps.setString(6, c.getAddress());
            ps.setString(7, c.getCity());        ps.setString(8, c.getState());
            ps.setString(9, c.getCountry());     ps.setString(10, c.getCustomerType());
            ps.setString(11, c.getStatus());     ps.setString(12, c.getNotes());
            ps.setInt(13, c.getCustomerId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    // ── DELETE ──────────────────────────────────────────
    public boolean deleteCustomer(int id) {
        String sql = "DELETE FROM customers WHERE customer_id=?";
        try (PreparedStatement ps = getConn().prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    // ── STATS ───────────────────────────────────────────
    public int getTotalCustomers()    { return countQuery("SELECT COUNT(*) FROM customers"); }
    public int getActiveCustomers()   { return countQuery("SELECT COUNT(*) FROM customers WHERE status='Active'"); }
    public int getVIPCustomers()      { return countQuery("SELECT COUNT(*) FROM customers WHERE customer_type='VIP'"); }
    public int getProspects()         { return countQuery("SELECT COUNT(*) FROM customers WHERE status='Prospect'"); }

    private int countQuery(String sql) {
        try (Statement st = getConn().createStatement(); ResultSet rs = st.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { e.printStackTrace(); }
        return 0;
    }

    // ── MAPPER ──────────────────────────────────────────
    private Customer mapRow(ResultSet rs) throws SQLException {
        Customer c = new Customer();
        c.setCustomerId(rs.getInt("customer_id"));
        c.setFirstName(rs.getString("first_name"));
        c.setLastName(rs.getString("last_name"));
        c.setEmail(rs.getString("email"));
        c.setPhone(rs.getString("phone"));
        c.setCompany(rs.getString("company"));
        c.setAddress(rs.getString("address"));
        c.setCity(rs.getString("city"));
        c.setState(rs.getString("state"));
        c.setCountry(rs.getString("country"));
        c.setCustomerType(rs.getString("customer_type"));
        c.setStatus(rs.getString("status"));
        c.setNotes(rs.getString("notes"));
        c.setCreatedAt(rs.getTimestamp("created_at"));
        c.setUpdatedAt(rs.getTimestamp("updated_at"));
        return c;
    }
}
