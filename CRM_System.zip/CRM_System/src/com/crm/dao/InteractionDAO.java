package com.crm.dao;

import com.crm.model.Interaction;
import com.crm.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class InteractionDAO {

    private Connection getConn() {
        return DatabaseConnection.getInstance().getConnection();
    }

    public boolean addInteraction(Interaction i) {
        String sql = "INSERT INTO interactions (customer_id,interaction_type,subject,description,outcome,next_follow_up,created_by) VALUES (?,?,?,?,?,?,?)";
        try (PreparedStatement ps = getConn().prepareStatement(sql)) {
            ps.setInt(1, i.getCustomerId());
            ps.setString(2, i.getInteractionType());
            ps.setString(3, i.getSubject());
            ps.setString(4, i.getDescription());
            ps.setString(5, i.getOutcome());
            ps.setDate(6, i.getNextFollowUp());
            ps.setString(7, i.getCreatedBy());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public List<Interaction> getAllInteractions() {
        List<Interaction> list = new ArrayList<>();
        String sql = "SELECT i.*, CONCAT(c.first_name,' ',c.last_name) AS customer_name FROM interactions i JOIN customers c ON i.customer_id=c.customer_id ORDER BY i.interaction_date DESC";
        try (Statement st = getConn().createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public List<Interaction> getInteractionsByCustomer(int customerId) {
        List<Interaction> list = new ArrayList<>();
        String sql = "SELECT i.*, CONCAT(c.first_name,' ',c.last_name) AS customer_name FROM interactions i JOIN customers c ON i.customer_id=c.customer_id WHERE i.customer_id=? ORDER BY i.interaction_date DESC";
        try (PreparedStatement ps = getConn().prepareStatement(sql)) {
            ps.setInt(1, customerId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public boolean deleteInteraction(int id) {
        String sql = "DELETE FROM interactions WHERE interaction_id=?";
        try (PreparedStatement ps = getConn().prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public int getTotalInteractions()    { return countQuery("SELECT COUNT(*) FROM interactions"); }
    public int getTodayInteractions()    { return countQuery("SELECT COUNT(*) FROM interactions WHERE DATE(interaction_date)=CURDATE()"); }

    private int countQuery(String sql) {
        try (Statement st = getConn().createStatement(); ResultSet rs = st.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { e.printStackTrace(); }
        return 0;
    }

    private Interaction mapRow(ResultSet rs) throws SQLException {
        Interaction i = new Interaction();
        i.setInteractionId(rs.getInt("interaction_id"));
        i.setCustomerId(rs.getInt("customer_id"));
        i.setInteractionType(rs.getString("interaction_type"));
        i.setSubject(rs.getString("subject"));
        i.setDescription(rs.getString("description"));
        i.setOutcome(rs.getString("outcome"));
        i.setInteractionDate(rs.getTimestamp("interaction_date"));
        i.setNextFollowUp(rs.getDate("next_follow_up"));
        i.setCreatedBy(rs.getString("created_by"));
        try { i.setCustomerName(rs.getString("customer_name")); } catch (SQLException ignored) {}
        return i;
    }
}
