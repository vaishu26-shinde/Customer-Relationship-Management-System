package com.crm.dao;

import com.crm.model.Deal;
import com.crm.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DealDAO {

    private Connection getConn() {
        return DatabaseConnection.getInstance().getConnection();
    }

    public boolean addDeal(Deal d) {
        String sql = "INSERT INTO deals (customer_id,deal_name,value,stage,close_date,probability,notes) VALUES (?,?,?,?,?,?,?)";
        try (PreparedStatement ps = getConn().prepareStatement(sql)) {
            ps.setInt(1, d.getCustomerId());
            ps.setString(2, d.getDealName());
            ps.setDouble(3, d.getValue());
            ps.setString(4, d.getStage());
            ps.setDate(5, d.getCloseDate());
            ps.setInt(6, d.getProbability());
            ps.setString(7, d.getNotes());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public List<Deal> getAllDeals() {
        List<Deal> list = new ArrayList<>();
        String sql = "SELECT d.*, CONCAT(c.first_name,' ',c.last_name) AS customer_name FROM deals d JOIN customers c ON d.customer_id=c.customer_id ORDER BY d.created_at DESC";
        try (Statement st = getConn().createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public boolean updateDeal(Deal d) {
        String sql = "UPDATE deals SET deal_name=?,value=?,stage=?,close_date=?,probability=?,notes=? WHERE deal_id=?";
        try (PreparedStatement ps = getConn().prepareStatement(sql)) {
            ps.setString(1, d.getDealName()); ps.setDouble(2, d.getValue());
            ps.setString(3, d.getStage());    ps.setDate(4, d.getCloseDate());
            ps.setInt(5, d.getProbability()); ps.setString(6, d.getNotes());
            ps.setInt(7, d.getDealId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public boolean deleteDeal(int id) {
        String sql = "DELETE FROM deals WHERE deal_id=?";
        try (PreparedStatement ps = getConn().prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public double getTotalPipelineValue() {
        String sql = "SELECT COALESCE(SUM(value),0) FROM deals WHERE stage NOT IN ('Won','Lost')";
        try (Statement st = getConn().createStatement(); ResultSet rs = st.executeQuery(sql)) {
            if (rs.next()) return rs.getDouble(1);
        } catch (SQLException e) { e.printStackTrace(); }
        return 0;
    }

    public int getWonDeals() { return countQuery("SELECT COUNT(*) FROM deals WHERE stage='Won'"); }

    private int countQuery(String sql) {
        try (Statement st = getConn().createStatement(); ResultSet rs = st.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { e.printStackTrace(); }
        return 0;
    }

    private Deal mapRow(ResultSet rs) throws SQLException {
        Deal d = new Deal();
        d.setDealId(rs.getInt("deal_id"));
        d.setCustomerId(rs.getInt("customer_id"));
        d.setDealName(rs.getString("deal_name"));
        d.setValue(rs.getDouble("value"));
        d.setStage(rs.getString("stage"));
        d.setCloseDate(rs.getDate("close_date"));
        d.setProbability(rs.getInt("probability"));
        d.setNotes(rs.getString("notes"));
        d.setCreatedAt(rs.getTimestamp("created_at"));
        try { d.setCustomerName(rs.getString("customer_name")); } catch (SQLException ignored) {}
        return d;
    }
}
