package com.crm.dao;

import com.crm.model.ServiceTicket;
import com.crm.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ServiceTicketDAO {

    private Connection getConn() {
        return DatabaseConnection.getInstance().getConnection();
    }

    private String generateTicketNumber() {
        return "TKT-" + String.format("%04d", (int)(Math.random() * 9000) + 1000);
    }

    public boolean addTicket(ServiceTicket t) {
        t.setTicketNumber(generateTicketNumber());
        String sql = "INSERT INTO service_history (customer_id,service_type,description,status,priority,ticket_number,assigned_to,resolution) VALUES (?,?,?,?,?,?,?,?)";
        try (PreparedStatement ps = getConn().prepareStatement(sql)) {
            ps.setInt(1, t.getCustomerId());
            ps.setString(2, t.getServiceType());
            ps.setString(3, t.getDescription());
            ps.setString(4, t.getStatus());
            ps.setString(5, t.getPriority());
            ps.setString(6, t.getTicketNumber());
            ps.setString(7, t.getAssignedTo());
            ps.setString(8, t.getResolution());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public List<ServiceTicket> getAllTickets() {
        List<ServiceTicket> list = new ArrayList<>();
        String sql = "SELECT s.*, CONCAT(c.first_name,' ',c.last_name) AS customer_name FROM service_history s JOIN customers c ON s.customer_id=c.customer_id ORDER BY s.service_date DESC";
        try (Statement st = getConn().createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public List<ServiceTicket> getTicketsByCustomer(int customerId) {
        List<ServiceTicket> list = new ArrayList<>();
        String sql = "SELECT s.*, CONCAT(c.first_name,' ',c.last_name) AS customer_name FROM service_history s JOIN customers c ON s.customer_id=c.customer_id WHERE s.customer_id=? ORDER BY s.service_date DESC";
        try (PreparedStatement ps = getConn().prepareStatement(sql)) {
            ps.setInt(1, customerId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public boolean updateTicketStatus(int serviceId, String status, String resolution) {
        String sql = "UPDATE service_history SET status=?, resolution=?, resolved_date=? WHERE service_id=?";
        try (PreparedStatement ps = getConn().prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setString(2, resolution);
            ps.setTimestamp(3, status.equals("Resolved") || status.equals("Closed") ? new Timestamp(System.currentTimeMillis()) : null);
            ps.setInt(4, serviceId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public boolean deleteTicket(int id) {
        String sql = "DELETE FROM service_history WHERE service_id=?";
        try (PreparedStatement ps = getConn().prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public int getOpenTickets()      { return countQuery("SELECT COUNT(*) FROM service_history WHERE status IN ('Pending','In Progress')"); }
    public int getResolvedTickets()  { return countQuery("SELECT COUNT(*) FROM service_history WHERE status IN ('Resolved','Closed')"); }

    private int countQuery(String sql) {
        try (Statement st = getConn().createStatement(); ResultSet rs = st.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { e.printStackTrace(); }
        return 0;
    }

    private ServiceTicket mapRow(ResultSet rs) throws SQLException {
        ServiceTicket t = new ServiceTicket();
        t.setServiceId(rs.getInt("service_id"));
        t.setCustomerId(rs.getInt("customer_id"));
        t.setServiceType(rs.getString("service_type"));
        t.setDescription(rs.getString("description"));
        t.setStatus(rs.getString("status"));
        t.setPriority(rs.getString("priority"));
        t.setTicketNumber(rs.getString("ticket_number"));
        t.setAssignedTo(rs.getString("assigned_to"));
        t.setResolution(rs.getString("resolution"));
        t.setServiceDate(rs.getTimestamp("service_date"));
        t.setResolvedDate(rs.getTimestamp("resolved_date"));
        try { t.setCustomerName(rs.getString("customer_name")); } catch (SQLException ignored) {}
        return t;
    }
}
