package com.crm.util;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;

/**
 * Centralized UI theme for the CRM application.
 * Dark navy + electric-blue accent palette.
 */
public class UITheme {

    // ── Palette ───────────────────────────────────────
    public static final Color BG_DARK       = new Color(13, 17, 30);
    public static final Color BG_CARD       = new Color(22, 28, 48);
    public static final Color BG_SIDEBAR    = new Color(16, 21, 38);
    public static final Color ACCENT        = new Color(56, 139, 255);
    public static final Color ACCENT_HOVER  = new Color(80, 160, 255);
    public static final Color ACCENT_GREEN  = new Color(34, 197, 94);
    public static final Color ACCENT_RED    = new Color(239, 68, 68);
    public static final Color ACCENT_YELLOW = new Color(250, 176, 5);
    public static final Color ACCENT_PURPLE = new Color(167, 105, 255);
    public static final Color TEXT_PRIMARY  = new Color(230, 235, 255);
    public static final Color TEXT_MUTED    = new Color(130, 145, 175);
    public static final Color BORDER_COLOR  = new Color(40, 52, 80);
    public static final Color TABLE_ROW_ODD = new Color(19, 25, 44);
    public static final Color TABLE_ROW_EVEN= new Color(24, 32, 55);
    public static final Color TABLE_HOVER   = new Color(35, 50, 90);
    public static final Color TABLE_SELECT  = new Color(56, 139, 255, 80);

    // ── Fonts ─────────────────────────────────────────
    public static final Font FONT_TITLE     = new Font("Segoe UI", Font.BOLD, 22);
    public static final Font FONT_HEADING   = new Font("Segoe UI", Font.BOLD, 14);
    public static final Font FONT_BODY      = new Font("Segoe UI", Font.PLAIN, 13);
    public static final Font FONT_SMALL     = new Font("Segoe UI", Font.PLAIN, 11);
    public static final Font FONT_MONO      = new Font("Consolas", Font.PLAIN, 12);
    public static final Font FONT_LABEL     = new Font("Segoe UI", Font.BOLD, 12);

    // ── Global L&F ────────────────────────────────────
    public static void apply() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}
        UIManager.put("Panel.background",           BG_DARK);
        UIManager.put("ScrollPane.background",      BG_DARK);
        UIManager.put("Table.background",           TABLE_ROW_ODD);
        UIManager.put("Table.foreground",           TEXT_PRIMARY);
        UIManager.put("Table.gridColor",            BORDER_COLOR);
        UIManager.put("Table.selectionBackground",  TABLE_SELECT);
        UIManager.put("Table.selectionForeground",  TEXT_PRIMARY);
        UIManager.put("TableHeader.background",     BG_CARD);
        UIManager.put("TableHeader.foreground",     ACCENT);
        UIManager.put("TableHeader.font",           FONT_LABEL);
        UIManager.put("TextField.background",       BG_CARD);
        UIManager.put("TextField.foreground",       TEXT_PRIMARY);
        UIManager.put("TextField.caretForeground",  ACCENT);
        UIManager.put("TextArea.background",        BG_CARD);
        UIManager.put("TextArea.foreground",        TEXT_PRIMARY);
        UIManager.put("ComboBox.background",        BG_CARD);
        UIManager.put("ComboBox.foreground",        TEXT_PRIMARY);
        UIManager.put("Label.foreground",           TEXT_PRIMARY);
        UIManager.put("ScrollBar.background",       BG_DARK);
        UIManager.put("ScrollBar.thumb",            BORDER_COLOR);
        UIManager.put("OptionPane.background",      BG_CARD);
        UIManager.put("OptionPane.messageForeground", TEXT_PRIMARY);
    }

    // ── Factory Methods ───────────────────────────────

    public static JButton primaryButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_LABEL);
        btn.setBackground(ACCENT);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createEmptyBorder(8, 18, 8, 18));
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { btn.setBackground(ACCENT_HOVER); }
            public void mouseExited(MouseEvent e)  { btn.setBackground(ACCENT); }
        });
        return btn;
    }

    public static JButton dangerButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_LABEL);
        btn.setBackground(ACCENT_RED);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createEmptyBorder(8, 18, 8, 18));
        return btn;
    }

    public static JButton successButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_LABEL);
        btn.setBackground(ACCENT_GREEN);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createEmptyBorder(8, 18, 8, 18));
        return btn;
    }

    public static JTextField styledField(int cols) {
        JTextField tf = new JTextField(cols);
        tf.setFont(FONT_BODY);
        tf.setBackground(BG_DARK);
        tf.setForeground(TEXT_PRIMARY);
        tf.setCaretColor(ACCENT);
        tf.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_COLOR, 1),
            BorderFactory.createEmptyBorder(5, 8, 5, 8)
        ));
        return tf;
    }

    public static JTextArea styledArea(int rows, int cols) {
        JTextArea ta = new JTextArea(rows, cols);
        ta.setFont(FONT_BODY);
        ta.setBackground(BG_DARK);
        ta.setForeground(TEXT_PRIMARY);
        ta.setCaretColor(ACCENT);
        ta.setLineWrap(true);
        ta.setWrapStyleWord(true);
        ta.setBorder(BorderFactory.createEmptyBorder(6, 8, 6, 8));
        return ta;
    }

    public static JComboBox<String> styledCombo(String[] items) {
        JComboBox<String> cb = new JComboBox<>(items);
        cb.setFont(FONT_BODY);
        cb.setBackground(BG_DARK);
        cb.setForeground(TEXT_PRIMARY);
        cb.setBorder(BorderFactory.createLineBorder(BORDER_COLOR, 1));
        return cb;
    }

    public static JLabel headerLabel(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(FONT_HEADING);
        lbl.setForeground(TEXT_PRIMARY);
        return lbl;
    }

    public static JLabel muted(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(FONT_SMALL);
        lbl.setForeground(TEXT_MUTED);
        return lbl;
    }

    public static JPanel card() {
        JPanel p = new JPanel();
        p.setBackground(BG_CARD);
        p.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_COLOR, 1),
            BorderFactory.createEmptyBorder(16, 16, 16, 16)
        ));
        return p;
    }

    public static JScrollPane styledScroll(Component c) {
        JScrollPane sp = new JScrollPane(c);
        sp.setBackground(BG_DARK);
        sp.setBorder(BorderFactory.createLineBorder(BORDER_COLOR, 1));
        sp.getViewport().setBackground(BG_DARK);
        sp.getVerticalScrollBar().setBackground(BG_DARK);
        sp.getHorizontalScrollBar().setBackground(BG_DARK);
        return sp;
    }

    /** Alternating-row striped table renderer */
    public static void styleTable(JTable table) {
        table.setFont(FONT_BODY);
        table.setRowHeight(32);
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 0));
        table.setSelectionBackground(TABLE_SELECT);
        table.setSelectionForeground(TEXT_PRIMARY);
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object val, boolean sel, boolean foc, int row, int col) {
                Component c = super.getTableCellRendererComponent(t, val, sel, foc, row, col);
                if (sel) {
                    c.setBackground(TABLE_SELECT);
                } else {
                    c.setBackground(row % 2 == 0 ? TABLE_ROW_EVEN : TABLE_ROW_ODD);
                }
                c.setForeground(TEXT_PRIMARY);
                setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 8));
                return c;
            }
        });
        JTableHeader header = table.getTableHeader();
        header.setFont(FONT_LABEL);
        header.setBackground(BG_CARD);
        header.setForeground(ACCENT);
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_COLOR));
        header.setReorderingAllowed(false);
    }

    /** Coloured badge label */
    public static JLabel badge(String text, Color bg) {
        JLabel lbl = new JLabel(" " + text + " ");
        lbl.setFont(FONT_SMALL);
        lbl.setForeground(Color.WHITE);
        lbl.setOpaque(true);
        lbl.setBackground(bg);
        lbl.setBorder(BorderFactory.createEmptyBorder(2, 6, 2, 6));
        return lbl;
    }

    public static Color statusColor(String status) {
        if (status == null) return TEXT_MUTED;
        switch (status) {
            case "Active":
            case "Resolved":
            case "Closed":
            case "Won":
                return ACCENT_GREEN;
            case "Inactive":
            case "Lost":
            case "Cancelled":
                return ACCENT_RED;
            case "Prospect":
            case "Lead":
            case "Pending":
                return ACCENT_YELLOW;
            case "In Progress":
            case "Negotiation":
                return ACCENT;
            case "VIP":
                return ACCENT_PURPLE;
            default:
                return TEXT_MUTED;
        }
    }
}
