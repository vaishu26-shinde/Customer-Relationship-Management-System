package com.crm.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Database connection manager (Singleton pattern)
 */
public class DatabaseConnection {

    private static final String URL      = "jdbc:mysql://localhost:3306/crm_schema?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
    private static final String USER     = "root";          // ← change if needed
    private static final String PASSWORD = ""; // ← change to your MySQL password

    private static DatabaseConnection instance;
    private Connection connection;

    private DatabaseConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (ClassNotFoundException e) {
            System.err.println("MySQL JDBC Driver not found. Add mysql-connector-java.jar to /lib");
            e.printStackTrace();
        } catch (SQLException e) {
            System.err.println("Database connection failed. Check credentials in DatabaseConnection.java");
            e.printStackTrace();
        }
    }

    public static DatabaseConnection getInstance() {
        if (instance == null || !instance.isConnected()) {
            instance = new DatabaseConnection();
        }
        return instance;
    }

    public Connection getConnection() {
        return connection;
    }

    private boolean isConnected() {
        try {
            return connection != null && !connection.isClosed();
        } catch (SQLException e) {
            return false;
        }
    }

    public void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
