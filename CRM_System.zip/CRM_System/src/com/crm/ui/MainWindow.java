package com.crm.ui;

import com.crm.util.UITheme;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * Main application window — dark sidebar navigation + content area.
 */
public class MainWindow extends JFrame {

    private JPanel contentArea;
    private CardLayout cardLayout;

    private DashboardPanel   dashboardPanel;
    private CustomerPanel    customerPanel;
    private InteractionPanel interactionPanel;
    private ServicePanel     servicePanel;
    private DealsPanel       dealsPanel;

    private JButton activeBtn = null;

    public MainWindow() {
        setTitle("CRM Pro — Customer Relationship Management");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1280, 780);
        setMinimumSize(new Dimension(960, 620));
        setLocationRelativeTo(null);
        getContentPane().setBackground(UITheme.BG_DARK);
        UITheme.apply();
        buildUI();
        setVisible(true);
    }

    private void buildUI() {
        setLayout(new BorderLayout(0, 0));

        // ── Sidebar ──────────────────────────────────────
        JPanel sidebar = buildSidebar();

        // ── Content ──────────────────────────────────────
        cardLayout  = new CardLayout();
        contentArea = new JPanel(cardLayout);
        contentArea.setBackground(UITheme.BG_DARK);

        dashboardPanel   = new DashboardPanel();
        customerPanel    = new CustomerPanel();
        interactionPanel = new InteractionPanel();
        servicePanel     = new ServicePanel();
        dealsPanel       = new DealsPanel();

        contentArea.add(dashboardPanel,   "dashboard");
        contentArea.add(customerPanel,    "customers");
        contentArea.add(interactionPanel, "interactions");
        contentArea.add(servicePanel,     "service");
        contentArea.add(dealsPanel,       "deals");

        add(sidebar,     BorderLayout.WEST);
        add(contentArea, BorderLayout.CENTER);
    }

    private JPanel buildSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(UITheme.BG_SIDEBAR);
        sidebar.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, UITheme.BORDER_COLOR));
        sidebar.setPreferredSize(new Dimension(220, 0));

        // ── Logo area ────────────────────────────────────
        JPanel logoPanel = new JPanel();
        logoPanel.setBackground(UITheme.BG_SIDEBAR);
        logoPanel.setLayout(new BoxLayout(logoPanel, BoxLayout.Y_AXIS));
        logoPanel.setBorder(BorderFactory.createEmptyBorder(24, 20, 20, 20));
        logoPanel.setMaximumSize(new Dimension(220, 100));

        JLabel logo = new JLabel("◈ CRM Pro");
        logo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        logo.setForeground(UITheme.ACCENT);
        logo.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel tagline = UITheme.muted("Customer Management System");
        tagline.setAlignmentX(Component.LEFT_ALIGNMENT);

        logoPanel.add(logo);
        logoPanel.add(Box.createVerticalStrut(4));
        logoPanel.add(tagline);

        // ── Divider ──────────────────────────────────────
        JSeparator sep = new JSeparator();
        sep.setForeground(UITheme.BORDER_COLOR);
        sep.setMaximumSize(new Dimension(220, 1));

        // ── Nav label ────────────────────────────────────
        JLabel navLabel = UITheme.muted("  NAVIGATION");
        navLabel.setBorder(BorderFactory.createEmptyBorder(16, 16, 6, 0));
        navLabel.setMaximumSize(new Dimension(220, 30));
        navLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        sidebar.add(logoPanel);
        sidebar.add(sep);
        sidebar.add(navLabel);

        // ── Nav buttons ──────────────────────────────────
        JButton[] navBtns = {
            navButton("🏠  Dashboard",    "dashboard"),
            navButton("👥  Customers",    "customers"),
            navButton("💬  Interactions", "interactions"),
            navButton("🎫  Service Desk", "service"),
            navButton("💰  Deals",        "deals"),
        };
        for (JButton btn : navBtns) {
            sidebar.add(btn);
            sidebar.add(Box.createVerticalStrut(2));
        }

        // activate dashboard by default
        setActive(navBtns[0]);

        sidebar.add(Box.createVerticalGlue());

        // ── Footer ───────────────────────────────────────
        JSeparator sep2 = new JSeparator();
        sep2.setForeground(UITheme.BORDER_COLOR);
        sep2.setMaximumSize(new Dimension(220, 1));
        sidebar.add(sep2);

        JPanel footer = new JPanel(new FlowLayout(FlowLayout.LEFT));
        footer.setBackground(UITheme.BG_SIDEBAR);
        footer.setMaximumSize(new Dimension(220, 52));
        JLabel versionLbl = UITheme.muted("v1.0  •  BTech Project 2026");
        footer.add(versionLbl);
        sidebar.add(footer);

        return sidebar;
    }

    private JButton navButton(String text, String card) {
        JButton btn = new JButton(text);
        btn.setFont(UITheme.FONT_BODY);
        btn.setForeground(UITheme.TEXT_MUTED);
        btn.setBackground(UITheme.BG_SIDEBAR);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setMaximumSize(new Dimension(220, 42));
        btn.setPreferredSize(new Dimension(220, 42));
        btn.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 0));

        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                if (btn != activeBtn) btn.setBackground(UITheme.BG_CARD);
            }
            public void mouseExited(MouseEvent e) {
                if (btn != activeBtn) btn.setBackground(UITheme.BG_SIDEBAR);
            }
        });

        btn.addActionListener(e -> {
            setActive(btn);
            cardLayout.show(contentArea, card);
            refreshPanel(card);
        });
        return btn;
    }

    private void setActive(JButton btn) {
        if (activeBtn != null) {
            activeBtn.setBackground(UITheme.BG_SIDEBAR);
            activeBtn.setForeground(UITheme.TEXT_MUTED);
            activeBtn.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 0));
        }
        activeBtn = btn;
        btn.setBackground(new Color(30, 45, 80));
        btn.setForeground(UITheme.ACCENT);
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 3, 0, 0, UITheme.ACCENT),
            BorderFactory.createEmptyBorder(0, 17, 0, 0)
        ));
    }

    private void refreshPanel(String card) {
        switch (card) {
            case "dashboard":
                dashboardPanel.refresh();
                break;
            case "customers":
                customerPanel.refresh();
                break;
            case "interactions":
                interactionPanel.refresh();
                break;
            case "service":
                servicePanel.refresh();
                break;
            case "deals":
                dealsPanel.refresh();
                break;
        }
    }
}
