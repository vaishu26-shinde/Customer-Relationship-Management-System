package com.crm.ui;

import com.crm.dao.CustomerDAO;
import com.crm.dao.ServiceTicketDAO;
import com.crm.model.Customer;
import com.crm.model.ServiceTicket;
import com.crm.util.UITheme;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class ServicePanel extends JPanel {

    private final ServiceTicketDAO dao = new ServiceTicketDAO();
    private final CustomerDAO customerDAO = new CustomerDAO();
    private JTable table;
    private DefaultTableModel tableModel;

    private static final String[] COLS = {"ID","Ticket#","Customer","Service Type","Priority","Status","Assigned To","Date"};

    public ServicePanel() {
        setLayout(new BorderLayout());
        setBackground(UITheme.BG_DARK);
        setBorder(BorderFactory.createEmptyBorder(24,24,24,24));
        buildUI();
        loadData();
    }

    private void buildUI() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(UITheme.BG_DARK);
        header.setBorder(BorderFactory.createEmptyBorder(0,0,20,0));

        JLabel title = new JLabel("Service History & Tickets");
        title.setFont(UITheme.FONT_TITLE);
        title.setForeground(UITheme.TEXT_PRIMARY);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnPanel.setBackground(UITheme.BG_DARK);
        JButton addBtn    = UITheme.successButton("+ New Ticket");
        JButton updateBtn = UITheme.primaryButton("✏ Update Status");
        JButton deleteBtn = UITheme.dangerButton("🗑 Delete");
        JButton refreshBtn = UITheme.primaryButton("↻ Refresh");
        btnPanel.add(addBtn); btnPanel.add(updateBtn); btnPanel.add(deleteBtn); btnPanel.add(refreshBtn);

        header.add(title, BorderLayout.WEST);
        header.add(btnPanel, BorderLayout.EAST);

        tableModel = new DefaultTableModel(COLS, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        UITheme.styleTable(table);
        table.getColumnModel().getColumn(0).setPreferredWidth(40);
        table.getColumnModel().getColumn(1).setPreferredWidth(90);
        table.getColumnModel().getColumn(2).setPreferredWidth(160);
        table.getColumnModel().getColumn(3).setPreferredWidth(160);

        // Priority renderer
        table.getColumnModel().getColumn(4).setCellRenderer(badgeRenderer());
        // Status renderer
        table.getColumnModel().getColumn(5).setCellRenderer(new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foc, int r, int c) {
                JLabel lbl = (JLabel) super.getTableCellRendererComponent(t, v, sel, foc, r, c);
                lbl.setForeground(UITheme.statusColor(v != null ? v.toString() : ""));
                lbl.setFont(UITheme.FONT_LABEL);
                lbl.setBackground(sel ? UITheme.TABLE_SELECT : (r%2==0 ? UITheme.TABLE_ROW_EVEN : UITheme.TABLE_ROW_ODD));
                lbl.setOpaque(true); lbl.setBorder(BorderFactory.createEmptyBorder(0,8,0,8));
                return lbl;
            }
        });

        add(header, BorderLayout.NORTH);
        add(UITheme.styledScroll(table), BorderLayout.CENTER);

        addBtn.addActionListener(e -> showAddForm());
        updateBtn.addActionListener(e -> showUpdateStatus());
        deleteBtn.addActionListener(e -> deleteSelected());
        refreshBtn.addActionListener(e -> loadData());
    }

    private DefaultTableCellRenderer badgeRenderer() {
        return new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foc, int r, int c) {
                JLabel lbl = (JLabel) super.getTableCellRendererComponent(t, v, sel, foc, r, c);
                String p = v != null ? v.toString() : "";
                Color col;
                switch (p) {
                    case "Critical":
                        col = UITheme.ACCENT_RED;
                        break;
                    case "High":
                        col = new Color(255, 120, 60);
                        break;
                    case "Medium":
                        col = UITheme.ACCENT_YELLOW;
                        break;
                    default:
                        col = UITheme.ACCENT_GREEN;
                        break;
                }
                lbl.setForeground(col);
                lbl.setFont(UITheme.FONT_LABEL);
                lbl.setBackground(sel ? UITheme.TABLE_SELECT : (r%2==0 ? UITheme.TABLE_ROW_EVEN : UITheme.TABLE_ROW_ODD));
                lbl.setOpaque(true); lbl.setBorder(BorderFactory.createEmptyBorder(0,8,0,8));
                return lbl;
            }
        };
    }

    private void loadData() {
        tableModel.setRowCount(0);
        for (ServiceTicket t : dao.getAllTickets()) {
            tableModel.addRow(new Object[]{
                t.getServiceId(), t.getTicketNumber(), t.getCustomerName(),
                t.getServiceType(), t.getPriority(), t.getStatus(),
                t.getAssignedTo() != null ? t.getAssignedTo() : "—",
                t.getServiceDate() != null ? t.getServiceDate().toString().substring(0,16) : "—"
            });
        }
    }

    private void showAddForm() {
        JDialog dlg = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "New Service Ticket", true);
        dlg.setSize(520, 480);
        dlg.setLocationRelativeTo(this);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(UITheme.BG_CARD);
        form.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));
        GridBagConstraints gc = new GridBagConstraints();
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = new Insets(6,6,6,6);

        List<Customer> customers = customerDAO.getAllCustomers();
        String[] names = customers.stream().map(c -> c.getCustomerId() + " – " + c.getFullName()).toArray(String[]::new);
        JComboBox<String> custBox     = UITheme.styledCombo(names);
        JTextField serviceType        = UITheme.styledField(28);
        JComboBox<String> priorityBox = UITheme.styledCombo(new String[]{"Low","Medium","High","Critical"});
        JComboBox<String> statusBox   = UITheme.styledCombo(new String[]{"Pending","In Progress","Resolved","Closed","Cancelled"});
        JTextField assignedTo         = UITheme.styledField(18);
        JTextArea  description        = UITheme.styledArea(3, 28);

        addRow(form, gc, 0, "Customer *",   custBox);
        addRow(form, gc, 1, "Service Type *", serviceType);
        addRow(form, gc, 2, "Priority",     priorityBox);
        addRow(form, gc, 3, "Status",       statusBox);
        addRow(form, gc, 4, "Assigned To",  assignedTo);
        gc.gridx=0; gc.gridy=5; gc.gridwidth=1;
        form.add(UITheme.muted("Description"), gc);
        gc.gridx=1; gc.gridwidth=2;
        form.add(UITheme.styledScroll(description), gc);

        JButton save   = UITheme.successButton("💾 Create Ticket");
        JButton cancel = UITheme.dangerButton("✕ Cancel");
        JPanel btnRow  = new JPanel(new FlowLayout(FlowLayout.RIGHT,8,0));
        btnRow.setBackground(UITheme.BG_CARD);
        btnRow.add(cancel); btnRow.add(save);

        save.addActionListener(e -> {
            if (custBox.getSelectedIndex() < 0 || serviceType.getText().isBlank()) {
                JOptionPane.showMessageDialog(dlg,"Customer and Service Type required.","Validation",JOptionPane.WARNING_MESSAGE); return;
            }
            ServiceTicket t = new ServiceTicket();
            t.setCustomerId(customers.get(custBox.getSelectedIndex()).getCustomerId());
            t.setServiceType(serviceType.getText().trim());
            t.setPriority((String) priorityBox.getSelectedItem());
            t.setStatus((String) statusBox.getSelectedItem());
            t.setAssignedTo(assignedTo.getText().trim());
            t.setDescription(description.getText().trim());

            if (dao.addTicket(t)) {
                JOptionPane.showMessageDialog(dlg,"Ticket created: "+t.getTicketNumber(),"Success",JOptionPane.INFORMATION_MESSAGE);
                dlg.dispose(); loadData();
            } else {
                JOptionPane.showMessageDialog(dlg,"Failed to create ticket.","Error",JOptionPane.ERROR_MESSAGE);
            }
        });
        cancel.addActionListener(e -> dlg.dispose());

        JPanel wrapper = new JPanel(new BorderLayout(0,12));
        wrapper.setBackground(UITheme.BG_DARK);
        wrapper.setBorder(BorderFactory.createEmptyBorder(12,12,12,12));
        wrapper.add(form, BorderLayout.CENTER);
        wrapper.add(btnRow, BorderLayout.SOUTH);
        dlg.setContentPane(wrapper);
        dlg.setVisible(true);
    }

    private void showUpdateStatus() {
        int row = table.getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this,"Select a ticket first.","No Selection",JOptionPane.WARNING_MESSAGE); return; }
        int id = (int) tableModel.getValueAt(row, 0);

        JComboBox<String> statusBox = UITheme.styledCombo(new String[]{"Pending","In Progress","Resolved","Closed","Cancelled"});
        statusBox.setSelectedItem(tableModel.getValueAt(row, 5).toString());
        JTextArea resolution = UITheme.styledArea(3, 28);

        JPanel form = new JPanel(new GridLayout(0,1,0,8));
        form.setBackground(UITheme.BG_CARD);
        form.setBorder(BorderFactory.createEmptyBorder(12,12,12,12));
        form.add(UITheme.muted("New Status:")); form.add(statusBox);
        form.add(UITheme.muted("Resolution Notes:")); form.add(UITheme.styledScroll(resolution));

        int result = JOptionPane.showConfirmDialog(this, form, "Update Ticket Status",
            JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result == JOptionPane.OK_OPTION) {
            dao.updateTicketStatus(id, (String) statusBox.getSelectedItem(), resolution.getText().trim());
            loadData();
        }
    }

    private void deleteSelected() {
        int row = table.getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this,"Select a ticket first.","No Selection",JOptionPane.WARNING_MESSAGE); return; }
        int confirm = JOptionPane.showConfirmDialog(this,"Delete this ticket?","Confirm",JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE);
        if (confirm == JOptionPane.YES_OPTION) { if(dao.deleteTicket((int)tableModel.getValueAt(row,0))) loadData(); }
    }

    private void addRow(JPanel p, GridBagConstraints gc, int row, String label, Component field) {
        gc.gridx=0; gc.gridy=row; gc.gridwidth=1; gc.weightx=0;
        JLabel l = UITheme.muted(label); l.setPreferredSize(new Dimension(100,28)); p.add(l,gc);
        gc.gridx=1; gc.gridwidth=2; gc.weightx=1; p.add(field,gc);
    }

    public void refresh() { loadData(); }
}
