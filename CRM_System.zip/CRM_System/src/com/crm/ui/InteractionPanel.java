package com.crm.ui;

import com.crm.dao.CustomerDAO;
import com.crm.dao.InteractionDAO;
import com.crm.model.Customer;
import com.crm.model.Interaction;
import com.crm.util.UITheme;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Date;
import java.util.List;

public class InteractionPanel extends JPanel {

    private final InteractionDAO dao         = new InteractionDAO();
    private final CustomerDAO    customerDAO = new CustomerDAO();
    private JTable table;
    private DefaultTableModel tableModel;

    private static final String[] COLS = {"ID","Customer","Type","Subject","Outcome","Date","Follow-Up"};

    public InteractionPanel() {
        setLayout(new BorderLayout());
        setBackground(UITheme.BG_DARK);
        setBorder(BorderFactory.createEmptyBorder(24, 24, 24, 24));
        buildUI();
        loadData();
    }

    private void buildUI() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(UITheme.BG_DARK);
        header.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));

        JLabel title = new JLabel("Customer Interactions");
        title.setFont(UITheme.FONT_TITLE);
        title.setForeground(UITheme.TEXT_PRIMARY);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnPanel.setBackground(UITheme.BG_DARK);
        JButton addBtn    = UITheme.successButton("+ Log Interaction");
        JButton deleteBtn = UITheme.dangerButton("🗑 Delete");
        JButton refreshBtn = UITheme.primaryButton("↻ Refresh");
        btnPanel.add(addBtn); btnPanel.add(deleteBtn); btnPanel.add(refreshBtn);

        header.add(title,    BorderLayout.WEST);
        header.add(btnPanel, BorderLayout.EAST);

        tableModel = new DefaultTableModel(COLS, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        UITheme.styleTable(table);
        table.getColumnModel().getColumn(0).setPreferredWidth(40);
        table.getColumnModel().getColumn(1).setPreferredWidth(160);
        table.getColumnModel().getColumn(2).setPreferredWidth(90);
        table.getColumnModel().getColumn(3).setPreferredWidth(220);
        table.getColumnModel().getColumn(4).setPreferredWidth(200);
        table.getColumnModel().getColumn(5).setPreferredWidth(130);

        // Type badge renderer
        table.getColumnModel().getColumn(2).setCellRenderer(new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foc, int r, int c) {
                JLabel lbl = (JLabel) super.getTableCellRendererComponent(t, v, sel, foc, r, c);
                lbl.setForeground(typeColor(v != null ? v.toString() : ""));
                lbl.setFont(UITheme.FONT_LABEL);
                lbl.setBackground(sel ? UITheme.TABLE_SELECT : (r%2==0 ? UITheme.TABLE_ROW_EVEN : UITheme.TABLE_ROW_ODD));
                lbl.setOpaque(true);
                lbl.setBorder(BorderFactory.createEmptyBorder(0,8,0,8));
                return lbl;
            }
        });

        add(header, BorderLayout.NORTH);
        add(UITheme.styledScroll(table), BorderLayout.CENTER);

        addBtn.addActionListener(e -> showForm());
        deleteBtn.addActionListener(e -> deleteSelected());
        refreshBtn.addActionListener(e -> loadData());
    }

    private Color typeColor(String type) {
        switch (type) {
            case "Call":
                return UITheme.ACCENT_GREEN;
            case "Email":
                return UITheme.ACCENT;
            case "Meeting":
                return UITheme.ACCENT_PURPLE;
            case "Support":
                return UITheme.ACCENT_RED;
            case "Follow-up":
                return UITheme.ACCENT_YELLOW;
            default:
                return UITheme.TEXT_MUTED;
        }
    }

    private void loadData() {
        tableModel.setRowCount(0);
        for (Interaction i : dao.getAllInteractions()) {
            tableModel.addRow(new Object[]{
                i.getInteractionId(),
                i.getCustomerName(),
                i.getInteractionType(),
                i.getSubject(),
                i.getOutcome() != null ? i.getOutcome() : "—",
                i.getInteractionDate() != null ? i.getInteractionDate().toString().substring(0,16) : "—",
                i.getNextFollowUp() != null ? i.getNextFollowUp().toString() : "—"
            });
        }
    }

    private void showForm() {
        JDialog dlg = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Log Interaction", true);
        dlg.setSize(540, 500);
        dlg.setLocationRelativeTo(this);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(UITheme.BG_CARD);
        form.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gc = new GridBagConstraints();
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = new Insets(6, 6, 6, 6);

        List<Customer> customers = customerDAO.getAllCustomers();
        String[] customerNames = customers.stream().map(c -> c.getCustomerId() + " – " + c.getFullName()).toArray(String[]::new);
        JComboBox<String> customerBox = UITheme.styledCombo(customerNames);
        JComboBox<String> typeBox     = UITheme.styledCombo(new String[]{"Call","Email","Meeting","Chat","Support","Follow-up"});
        JTextField subject   = UITheme.styledField(28);
        JTextArea  desc      = UITheme.styledArea(3, 28);
        JTextField outcome   = UITheme.styledField(28);
        JTextField followUp  = UITheme.styledField(12);
        followUp.putClientProperty("JTextField.placeholderText", "YYYY-MM-DD");

        addRow(form, gc, 0, "Customer *",   customerBox);
        addRow(form, gc, 1, "Type *",       typeBox);
        addRow(form, gc, 2, "Subject *",    subject);
        addRow(form, gc, 3, "Outcome",      outcome);
        addRow(form, gc, 4, "Follow-Up",    followUp);
        gc.gridx=0; gc.gridy=5; gc.gridwidth=1;
        form.add(UITheme.muted("Description"), gc);
        gc.gridx=1; gc.gridwidth=2;
        form.add(UITheme.styledScroll(desc), gc);

        JButton save   = UITheme.successButton("💾 Save");
        JButton cancel = UITheme.dangerButton("✕ Cancel");
        JPanel btnRow  = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnRow.setBackground(UITheme.BG_CARD);
        btnRow.add(cancel); btnRow.add(save);

        save.addActionListener(e -> {
            if (customerBox.getSelectedIndex() < 0 || subject.getText().isBlank()) {
                JOptionPane.showMessageDialog(dlg, "Customer and Subject are required.", "Validation", JOptionPane.WARNING_MESSAGE);
                return;
            }
            Interaction it = new Interaction();
            it.setCustomerId(customers.get(customerBox.getSelectedIndex()).getCustomerId());
            it.setInteractionType((String) typeBox.getSelectedItem());
            it.setSubject(subject.getText().trim());
            it.setDescription(desc.getText().trim());
            it.setOutcome(outcome.getText().trim());
            try {
                if (!followUp.getText().isBlank())
                    it.setNextFollowUp(Date.valueOf(followUp.getText().trim()));
            } catch (Exception ignored) {}

            if (dao.addInteraction(it)) {
                JOptionPane.showMessageDialog(dlg, "Interaction logged!", "Success", JOptionPane.INFORMATION_MESSAGE);
                dlg.dispose(); loadData();
            } else {
                JOptionPane.showMessageDialog(dlg, "Failed to save interaction.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        cancel.addActionListener(e -> dlg.dispose());

        JPanel wrapper = new JPanel(new BorderLayout(0,12));
        wrapper.setBackground(UITheme.BG_DARK);
        wrapper.setBorder(BorderFactory.createEmptyBorder(12,12,12,12));
        wrapper.add(form, BorderLayout.CENTER);
        wrapper.add(btnRow, BorderLayout.SOUTH);
        dlg.setContentPane(wrapper);
        dlg.setVisible(true);
    }

    private void addRow(JPanel p, GridBagConstraints gc, int row, String label, Component field) {
        gc.gridx=0; gc.gridy=row; gc.gridwidth=1; gc.weightx=0;
        JLabel l = UITheme.muted(label); l.setPreferredSize(new Dimension(100,28));
        p.add(l, gc);
        gc.gridx=1; gc.gridwidth=2; gc.weightx=1;
        p.add(field, gc);
    }

    private void deleteSelected() {
        int row = table.getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this,"Select an interaction first.","No Selection",JOptionPane.WARNING_MESSAGE); return; }
        int confirm = JOptionPane.showConfirmDialog(this,"Delete this interaction?","Confirm",JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE);
        if (confirm == JOptionPane.YES_OPTION) {
            if (dao.deleteInteraction((int) tableModel.getValueAt(row, 0))) loadData();
        }
    }

    public void refresh() { loadData(); }
}
