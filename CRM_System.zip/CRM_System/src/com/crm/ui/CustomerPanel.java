package com.crm.ui;

import com.crm.dao.CustomerDAO;
import com.crm.model.Customer;
import com.crm.util.UITheme;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class CustomerPanel extends JPanel {

    private final CustomerDAO dao = new CustomerDAO();
    private JTable table;
    private DefaultTableModel tableModel;
    private JTextField searchField;

    private static final String[] COLS = {"ID","Name","Email","Phone","Company","City","Type","Status"};

    public CustomerPanel() {
        setLayout(new BorderLayout(0, 0));
        setBackground(UITheme.BG_DARK);
        setBorder(BorderFactory.createEmptyBorder(24, 24, 24, 24));
        buildUI();
        loadData(dao.getAllCustomers());
    }

    private void buildUI() {
        // ── Header ──────────────────────────────────────
        JPanel header = new JPanel(new BorderLayout(12, 0));
        header.setBackground(UITheme.BG_DARK);
        header.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));

        JLabel title = new JLabel("Customer Management");
        title.setFont(UITheme.FONT_TITLE);
        title.setForeground(UITheme.TEXT_PRIMARY);

        JPanel rightBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        rightBar.setBackground(UITheme.BG_DARK);

        searchField = UITheme.styledField(22);
        searchField.putClientProperty("JTextField.placeholderText", "Search customers...");

        JButton searchBtn  = UITheme.primaryButton("🔍 Search");
        JButton addBtn     = UITheme.successButton("+ Add Customer");
        JButton editBtn    = UITheme.primaryButton("✏ Edit");
        JButton deleteBtn  = UITheme.dangerButton("🗑 Delete");
        JButton refreshBtn = UITheme.primaryButton("↻ Refresh");

        rightBar.add(searchField);
        rightBar.add(searchBtn);
        rightBar.add(Box.createHorizontalStrut(8));
        rightBar.add(addBtn);
        rightBar.add(editBtn);
        rightBar.add(deleteBtn);
        rightBar.add(refreshBtn);

        header.add(title,    BorderLayout.WEST);
        header.add(rightBar, BorderLayout.EAST);

        // ── Table ───────────────────────────────────────
        tableModel = new DefaultTableModel(COLS, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        UITheme.styleTable(table);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getColumnModel().getColumn(0).setPreferredWidth(40);
        table.getColumnModel().getColumn(1).setPreferredWidth(160);
        table.getColumnModel().getColumn(2).setPreferredWidth(200);
        table.getColumnModel().getColumn(3).setPreferredWidth(110);
        table.getColumnModel().getColumn(4).setPreferredWidth(130);
        table.getColumnModel().getColumn(5).setPreferredWidth(90);
        table.getColumnModel().getColumn(6).setPreferredWidth(90);

        // Status badge renderer
        table.getColumnModel().getColumn(7).setCellRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foc, int r, int c) {
                JLabel lbl = (JLabel) super.getTableCellRendererComponent(t, v, sel, foc, r, c);
                String status = v != null ? v.toString() : "";
                lbl.setForeground(UITheme.statusColor(status));
                lbl.setFont(UITheme.FONT_LABEL);
                lbl.setBackground(sel ? UITheme.TABLE_SELECT : (r % 2 == 0 ? UITheme.TABLE_ROW_EVEN : UITheme.TABLE_ROW_ODD));
                lbl.setOpaque(true);
                lbl.setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 8));
                return lbl;
            }
        });

        JScrollPane scroll = UITheme.styledScroll(table);

        // ── Status bar ──────────────────────────────────
        JPanel statusBar = new JPanel(new FlowLayout(FlowLayout.LEFT));
        statusBar.setBackground(UITheme.BG_DARK);
        JLabel statusLbl = UITheme.muted("Double-click a row to view full details");
        statusBar.add(statusLbl);

        add(header, BorderLayout.NORTH);
        add(scroll,  BorderLayout.CENTER);
        add(statusBar,BorderLayout.SOUTH);

        // ── Actions ─────────────────────────────────────
        searchBtn.addActionListener(e -> {
            String kw = searchField.getText().trim();
            loadData(kw.isEmpty() ? dao.getAllCustomers() : dao.searchCustomers(kw));
        });
        searchField.addActionListener(e -> searchBtn.doClick());

        addBtn.addActionListener(e -> showForm(null));
        editBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { JOptionPane.showMessageDialog(this, "Select a customer first.", "No Selection", JOptionPane.WARNING_MESSAGE); return; }
            int id = (int) tableModel.getValueAt(row, 0);
            showForm(dao.getCustomerById(id));
        });
        deleteBtn.addActionListener(e -> deleteSelected());
        refreshBtn.addActionListener(e -> { searchField.setText(""); loadData(dao.getAllCustomers()); });
        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int row = table.getSelectedRow();
                    if (row >= 0) showDetails((int) tableModel.getValueAt(row, 0));
                }
            }
        });
    }

    private void loadData(List<Customer> customers) {
        tableModel.setRowCount(0);
        for (Customer c : customers) {
            tableModel.addRow(new Object[]{
                c.getCustomerId(), c.getFullName(), c.getEmail(),
                c.getPhone(), c.getCompany() != null ? c.getCompany() : "—",
                c.getCity()  != null ? c.getCity()  : "—",
                c.getCustomerType(), c.getStatus()
            });
        }
    }

    private void showForm(Customer existing) {
        JDialog dlg = new JDialog((Frame) SwingUtilities.getWindowAncestor(this),
            existing == null ? "Add New Customer" : "Edit Customer", true);
        dlg.setSize(600, 640);
        dlg.setLocationRelativeTo(this);
        dlg.getContentPane().setBackground(UITheme.BG_DARK);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(UITheme.BG_CARD);
        form.setBorder(BorderFactory.createEmptyBorder(24, 24, 24, 24));
        GridBagConstraints gc = new GridBagConstraints();
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = new Insets(6, 6, 6, 6);

        JTextField fName    = UITheme.styledField(18);
        JTextField lName    = UITheme.styledField(18);
        JTextField email    = UITheme.styledField(28);
        JTextField phone    = UITheme.styledField(18);
        JTextField company  = UITheme.styledField(28);
        JTextField city     = UITheme.styledField(18);
        JTextField state    = UITheme.styledField(18);
        JTextField country  = UITheme.styledField(18);
        country.setText("India");
        JComboBox<String> typeBox   = UITheme.styledCombo(new String[]{"Individual","Corporate","VIP"});
        JComboBox<String> statusBox = UITheme.styledCombo(new String[]{"Active","Inactive","Prospect"});
        JTextArea notes = UITheme.styledArea(3, 28);

        if (existing != null) {
            fName.setText(existing.getFirstName());   lName.setText(existing.getLastName());
            email.setText(existing.getEmail());        phone.setText(existing.getPhone());
            company.setText(existing.getCompany());    city.setText(existing.getCity());
            state.setText(existing.getState());        country.setText(existing.getCountry());
            typeBox.setSelectedItem(existing.getCustomerType());
            statusBox.setSelectedItem(existing.getStatus());
            notes.setText(existing.getNotes());
        }

        addFormRow(form, gc, 0, "First Name *", fName);
        addFormRow(form, gc, 1, "Last Name *",  lName);
        addFormRow(form, gc, 2, "Email *",      email);
        addFormRow(form, gc, 3, "Phone",        phone);
        addFormRow(form, gc, 4, "Company",      company);
        addFormRow(form, gc, 5, "City",         city);
        addFormRow(form, gc, 6, "State",        state);
        addFormRow(form, gc, 7, "Country",      country);
        addFormRow(form, gc, 8, "Type",         typeBox);
        addFormRow(form, gc, 9, "Status",       statusBox);

        gc.gridx = 0; gc.gridy = 10; gc.gridwidth = 1;
        JLabel nl = UITheme.muted("Notes");
        nl.setForeground(UITheme.TEXT_MUTED);
        form.add(nl, gc);
        gc.gridx = 1; gc.gridwidth = 2;
        form.add(UITheme.styledScroll(notes), gc);

        JButton save = UITheme.successButton("💾 Save");
        JButton cancel = UITheme.dangerButton("✕ Cancel");
        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnRow.setBackground(UITheme.BG_CARD);
        btnRow.add(cancel); btnRow.add(save);

        save.addActionListener(e -> {
            if (fName.getText().isBlank() || lName.getText().isBlank() || email.getText().isBlank()) {
                JOptionPane.showMessageDialog(dlg, "First name, last name, and email are required.", "Validation", JOptionPane.WARNING_MESSAGE);
                return;
            }
            Customer c = existing != null ? existing : new Customer();
            c.setFirstName(fName.getText().trim());    c.setLastName(lName.getText().trim());
            c.setEmail(email.getText().trim());         c.setPhone(phone.getText().trim());
            c.setCompany(company.getText().trim());     c.setCity(city.getText().trim());
            c.setState(state.getText().trim());         c.setCountry(country.getText().trim());
            c.setCustomerType((String) typeBox.getSelectedItem());
            c.setStatus((String) statusBox.getSelectedItem());
            c.setNotes(notes.getText().trim());

            boolean ok = existing == null ? dao.addCustomer(c) : dao.updateCustomer(c);
            if (ok) {
                JOptionPane.showMessageDialog(dlg, "Customer saved successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                dlg.dispose();
                loadData(dao.getAllCustomers());
            } else {
                JOptionPane.showMessageDialog(dlg, "Failed to save. Check email uniqueness.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        cancel.addActionListener(e -> dlg.dispose());

        JPanel wrapper = new JPanel(new BorderLayout(0, 12));
        wrapper.setBackground(UITheme.BG_DARK);
        wrapper.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        wrapper.add(form, BorderLayout.CENTER);
        wrapper.add(btnRow, BorderLayout.SOUTH);
        dlg.setContentPane(wrapper);
        dlg.setVisible(true);
    }

    private void addFormRow(JPanel form, GridBagConstraints gc, int row, String label, Component field) {
        gc.gridx = 0; gc.gridy = row; gc.gridwidth = 1; gc.weightx = 0;
        JLabel lbl = UITheme.muted(label);
        lbl.setPreferredSize(new Dimension(110, 28));
        form.add(lbl, gc);
        gc.gridx = 1; gc.gridwidth = 2; gc.weightx = 1;
        form.add(field, gc);
    }

    private void deleteSelected() {
        int row = table.getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this, "Select a customer first.", "No Selection", JOptionPane.WARNING_MESSAGE); return; }
        String name = tableModel.getValueAt(row, 1).toString();
        int confirm = JOptionPane.showConfirmDialog(this,
            "Delete customer \"" + name + "\"?\nThis will also delete all related records.", "Confirm Delete",
            JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (confirm == JOptionPane.YES_OPTION) {
            if (dao.deleteCustomer((int) tableModel.getValueAt(row, 0)))
                loadData(dao.getAllCustomers());
        }
    }

    private void showDetails(int customerId) {
        Customer c = dao.getCustomerById(customerId);
        if (c == null) return;
        JOptionPane.showMessageDialog(this,
            buildDetailHtml(c), "Customer Details — " + c.getFullName(),
            JOptionPane.INFORMATION_MESSAGE);
    }

    private String buildDetailHtml(Customer c) {
        return "<html><body style='font-family:Segoe UI;font-size:13px;width:380px'>" +
            "<h2 style='color:#388bff'>" + c.getFullName() + "</h2>" +
            "<table cellpadding=4>" +
            row("Email",    c.getEmail()) + row("Phone",   c.getPhone()) +
            row("Company",  c.getCompany()) + row("City", c.getCity()) +
            row("State",    c.getState()) + row("Country", c.getCountry()) +
            row("Type",     c.getCustomerType()) + row("Status", c.getStatus()) +
            row("Created",  c.getCreatedAt() != null ? c.getCreatedAt().toString() : "—") +
            (c.getNotes() != null && !c.getNotes().isBlank() ? row("Notes", c.getNotes()) : "") +
            "</table></body></html>";
    }

    private String row(String k, String v) {
        return "<tr><td><b style='color:#8291af'>" + k + "</b></td><td style='color:#e6ebff'>" +
            (v != null && !v.isBlank() ? v : "—") + "</td></tr>";
    }

    public void refresh() { loadData(dao.getAllCustomers()); }
}
