package com.crm.ui;

import com.crm.dao.CustomerDAO;
import com.crm.dao.DealDAO;
import com.crm.model.Customer;
import com.crm.model.Deal;
import com.crm.util.UITheme;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Date;
import java.util.List;

public class DealsPanel extends JPanel {

    private final DealDAO     dao         = new DealDAO();
    private final CustomerDAO customerDAO = new CustomerDAO();
    private JTable table;
    private DefaultTableModel tableModel;

    private static final String[] COLS = {"ID","Customer","Deal Name","Value (₹)","Stage","Probability%","Close Date"};

    public DealsPanel() {
        setLayout(new BorderLayout());
        setBackground(UITheme.BG_DARK);
        setBorder(BorderFactory.createEmptyBorder(24,24,24,24));
        buildUI();
        loadData();
    }

    private void buildUI() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(UITheme.BG_DARK);
        header.setBorder(BorderFactory.createEmptyBorder(0,0,20,0));

        JLabel title = new JLabel("Deals & Sales Pipeline");
        title.setFont(UITheme.FONT_TITLE);
        title.setForeground(UITheme.TEXT_PRIMARY);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnPanel.setBackground(UITheme.BG_DARK);
        JButton addBtn    = UITheme.successButton("+ Add Deal");
        JButton editBtn   = UITheme.primaryButton("✏ Edit");
        JButton deleteBtn = UITheme.dangerButton("🗑 Delete");
        JButton refreshBtn = UITheme.primaryButton("↻ Refresh");
        btnPanel.add(addBtn); btnPanel.add(editBtn); btnPanel.add(deleteBtn); btnPanel.add(refreshBtn);

        header.add(title, BorderLayout.WEST);
        header.add(btnPanel, BorderLayout.EAST);

        tableModel = new DefaultTableModel(COLS, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        UITheme.styleTable(table);
        table.getColumnModel().getColumn(0).setPreferredWidth(40);
        table.getColumnModel().getColumn(1).setPreferredWidth(150);
        table.getColumnModel().getColumn(2).setPreferredWidth(200);
        table.getColumnModel().getColumn(3).setPreferredWidth(110);

        // Stage badge renderer
        table.getColumnModel().getColumn(4).setCellRenderer(new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foc, int r, int c) {
                JLabel lbl = (JLabel) super.getTableCellRendererComponent(t,v,sel,foc,r,c);
                String s = v != null ? v.toString() : "";
                Color col;
                switch (s) {
                    case "Won":
                        col = UITheme.ACCENT_GREEN;
                        break;
                    case "Lost":
                        col = UITheme.ACCENT_RED;
                        break;
                    case "Negotiation":
                        col = UITheme.ACCENT_YELLOW;
                        break;
                    case "Proposal":
                        col = UITheme.ACCENT;
                        break;
                    case "Qualified":
                        col = UITheme.ACCENT_PURPLE;
                        break;
                    default:
                        col = UITheme.TEXT_MUTED;
                        break;
                }
                lbl.setForeground(col);
                lbl.setFont(UITheme.FONT_LABEL);
                lbl.setBackground(sel ? UITheme.TABLE_SELECT : (r%2==0 ? UITheme.TABLE_ROW_EVEN : UITheme.TABLE_ROW_ODD));
                lbl.setOpaque(true); lbl.setBorder(BorderFactory.createEmptyBorder(0,8,0,8));
                return lbl;
            }
        });

        // Summary footer
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.LEFT, 16, 6));
        footer.setBackground(UITheme.BG_CARD);
        footer.setBorder(BorderFactory.createMatteBorder(1,0,0,0,UITheme.BORDER_COLOR));
        JLabel pipelineLbl = new JLabel("Pipeline: ₹" + String.format("%,.0f", dao.getTotalPipelineValue()));
        pipelineLbl.setFont(UITheme.FONT_HEADING);
        pipelineLbl.setForeground(UITheme.ACCENT);
        JLabel wonLbl = new JLabel("Deals Won: " + dao.getWonDeals());
        wonLbl.setFont(UITheme.FONT_HEADING);
        wonLbl.setForeground(UITheme.ACCENT_GREEN);
        footer.add(pipelineLbl); footer.add(wonLbl);

        add(header, BorderLayout.NORTH);
        add(UITheme.styledScroll(table), BorderLayout.CENTER);
        add(footer, BorderLayout.SOUTH);

        addBtn.addActionListener(e -> showForm(null));
        editBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { JOptionPane.showMessageDialog(this,"Select a deal first.","No Selection",JOptionPane.WARNING_MESSAGE); return; }
            int id = (int) tableModel.getValueAt(row, 0);
            Deal d = dao.getAllDeals().stream().filter(x -> x.getDealId() == id).findFirst().orElse(null);
            showForm(d);
        });
        deleteBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) return;
            if (JOptionPane.showConfirmDialog(this,"Delete this deal?","Confirm",JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE) == JOptionPane.YES_OPTION) {
                dao.deleteDeal((int) tableModel.getValueAt(row,0)); loadData();
            }
        });
        refreshBtn.addActionListener(e -> loadData());
    }

    private void loadData() {
        tableModel.setRowCount(0);
        for (Deal d : dao.getAllDeals()) {
            tableModel.addRow(new Object[]{
                d.getDealId(), d.getCustomerName(), d.getDealName(),
                String.format("%,.2f", d.getValue()), d.getStage(),
                d.getProbability() + "%",
                d.getCloseDate() != null ? d.getCloseDate().toString() : "—"
            });
        }
    }

    private void showForm(Deal existing) {
        JDialog dlg = new JDialog((Frame)SwingUtilities.getWindowAncestor(this),
            existing == null ? "Add Deal" : "Edit Deal", true);
        dlg.setSize(500, 440);
        dlg.setLocationRelativeTo(this);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(UITheme.BG_CARD);
        form.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));
        GridBagConstraints gc = new GridBagConstraints();
        gc.fill = GridBagConstraints.HORIZONTAL; gc.insets = new Insets(6,6,6,6);

        List<Customer> customers = customerDAO.getAllCustomers();
        String[] names = customers.stream().map(c -> c.getCustomerId() + " – " + c.getFullName()).toArray(String[]::new);
        JComboBox<String> custBox = UITheme.styledCombo(names);
        JTextField dealName   = UITheme.styledField(28);
        JTextField value      = UITheme.styledField(18);
        JComboBox<String> stageBox = UITheme.styledCombo(new String[]{"Lead","Qualified","Proposal","Negotiation","Won","Lost"});
        JTextField probability = UITheme.styledField(8);
        JTextField closeDate   = UITheme.styledField(12);
        closeDate.putClientProperty("JTextField.placeholderText","YYYY-MM-DD");
        JTextArea notes = UITheme.styledArea(2,28);

        if (existing != null) {
            for (int i=0; i<customers.size(); i++)
                if (customers.get(i).getCustomerId() == existing.getCustomerId()) { custBox.setSelectedIndex(i); break; }
            dealName.setText(existing.getDealName());
            value.setText(String.valueOf(existing.getValue()));
            stageBox.setSelectedItem(existing.getStage());
            probability.setText(String.valueOf(existing.getProbability()));
            if (existing.getCloseDate() != null) closeDate.setText(existing.getCloseDate().toString());
            notes.setText(existing.getNotes());
        }

        addRow(form,gc,0,"Customer *",  custBox);
        addRow(form,gc,1,"Deal Name *", dealName);
        addRow(form,gc,2,"Value (₹)",   value);
        addRow(form,gc,3,"Stage",       stageBox);
        addRow(form,gc,4,"Probability%",probability);
        addRow(form,gc,5,"Close Date",  closeDate);
        gc.gridx=0; gc.gridy=6; gc.gridwidth=1; form.add(UITheme.muted("Notes"),gc);
        gc.gridx=1; gc.gridwidth=2; form.add(UITheme.styledScroll(notes),gc);

        JButton save   = UITheme.successButton("💾 Save");
        JButton cancel = UITheme.dangerButton("✕ Cancel");
        JPanel btnRow  = new JPanel(new FlowLayout(FlowLayout.RIGHT,8,0));
        btnRow.setBackground(UITheme.BG_CARD);
        btnRow.add(cancel); btnRow.add(save);

        save.addActionListener(e -> {
            if (dealName.getText().isBlank()) { JOptionPane.showMessageDialog(dlg,"Deal Name is required.","Validation",JOptionPane.WARNING_MESSAGE); return; }
            Deal d = existing != null ? existing : new Deal();
            d.setCustomerId(customers.get(custBox.getSelectedIndex()).getCustomerId());
            d.setDealName(dealName.getText().trim());
            try { d.setValue(Double.parseDouble(value.getText().trim())); } catch (Exception ignored) {}
            d.setStage((String)stageBox.getSelectedItem());
            try { d.setProbability(Integer.parseInt(probability.getText().trim())); } catch (Exception ignored) {}
            try { if (!closeDate.getText().isBlank()) d.setCloseDate(Date.valueOf(closeDate.getText().trim())); } catch (Exception ignored) {}
            d.setNotes(notes.getText().trim());

            boolean ok = existing == null ? dao.addDeal(d) : dao.updateDeal(d);
            if (ok) { JOptionPane.showMessageDialog(dlg,"Deal saved!","Success",JOptionPane.INFORMATION_MESSAGE); dlg.dispose(); loadData(); }
            else    { JOptionPane.showMessageDialog(dlg,"Failed to save.","Error",JOptionPane.ERROR_MESSAGE); }
        });
        cancel.addActionListener(e -> dlg.dispose());

        JPanel wrapper = new JPanel(new BorderLayout(0,12));
        wrapper.setBackground(UITheme.BG_DARK);
        wrapper.setBorder(BorderFactory.createEmptyBorder(12,12,12,12));
        wrapper.add(form, BorderLayout.CENTER);
        wrapper.add(btnRow, BorderLayout.SOUTH);
        dlg.setContentPane(wrapper);
        dlg.setVisible(true);
    }

    private void addRow(JPanel p, GridBagConstraints gc, int row, String label, Component field) {
        gc.gridx=0; gc.gridy=row; gc.gridwidth=1; gc.weightx=0;
        JLabel l = UITheme.muted(label); l.setPreferredSize(new Dimension(100,28)); p.add(l,gc);
        gc.gridx=1; gc.gridwidth=2; gc.weightx=1; p.add(field,gc);
    }

    public void refresh() { loadData(); }
}
