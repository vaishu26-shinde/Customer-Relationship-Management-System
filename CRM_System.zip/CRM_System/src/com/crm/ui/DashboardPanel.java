package com.crm.ui;

import com.crm.dao.*;
import com.crm.util.UITheme;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class DashboardPanel extends JPanel {

    private final CustomerDAO     customerDAO     = new CustomerDAO();
    private final InteractionDAO  interactionDAO  = new InteractionDAO();
    private final ServiceTicketDAO ticketDAO      = new ServiceTicketDAO();
    private final DealDAO         dealDAO         = new DealDAO();

    public DashboardPanel() {
        setLayout(new BorderLayout(0, 0));
        setBackground(UITheme.BG_DARK);
        build();
    }

    private void build() {
        removeAll();

        // ── Top bar ──────────────────────────────────────
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(UITheme.BG_DARK);
        topBar.setBorder(BorderFactory.createEmptyBorder(0, 0, 24, 0));

        JLabel title = new JLabel("Dashboard Overview");
        title.setFont(UITheme.FONT_TITLE);
        title.setForeground(UITheme.TEXT_PRIMARY);

        String time = LocalDateTime.now().format(DateTimeFormatter.ofPattern("EEE, dd MMM yyyy • HH:mm"));
        JLabel dateLabel = UITheme.muted(time);
        dateLabel.setHorizontalAlignment(SwingConstants.RIGHT);

        topBar.add(title,     BorderLayout.WEST);
        topBar.add(dateLabel, BorderLayout.EAST);

        // ── KPI cards ────────────────────────────────────
        JPanel kpiRow = new JPanel(new GridLayout(1, 4, 16, 0));
        kpiRow.setBackground(UITheme.BG_DARK);
        kpiRow.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));

        kpiRow.add(kpiCard("Total Customers",   String.valueOf(customerDAO.getTotalCustomers()),    "👥", UITheme.ACCENT));
        kpiRow.add(kpiCard("Active Customers",  String.valueOf(customerDAO.getActiveCustomers()),   "✅", UITheme.ACCENT_GREEN));
        kpiRow.add(kpiCard("Open Tickets",      String.valueOf(ticketDAO.getOpenTickets()),          "🎫", UITheme.ACCENT_YELLOW));
        kpiRow.add(kpiCard("Deals Won",         String.valueOf(dealDAO.getWonDeals()),               "🏆", UITheme.ACCENT_PURPLE));

        // ── Second KPI row ───────────────────────────────
        JPanel kpiRow2 = new JPanel(new GridLayout(1, 4, 16, 0));
        kpiRow2.setBackground(UITheme.BG_DARK);
        kpiRow2.setBorder(BorderFactory.createEmptyBorder(0, 0, 24, 0));

        kpiRow2.add(kpiCard("VIP Customers",     String.valueOf(customerDAO.getVIPCustomers()),      "⭐", UITheme.ACCENT_YELLOW));
        kpiRow2.add(kpiCard("Prospects",         String.valueOf(customerDAO.getProspects()),          "🔍", UITheme.ACCENT));
        kpiRow2.add(kpiCard("Total Interactions",String.valueOf(interactionDAO.getTotalInteractions()),"💬", UITheme.ACCENT_GREEN));
        double pipeline = dealDAO.getTotalPipelineValue();
        kpiRow2.add(kpiCard("Pipeline Value", "₹" + formatLakh(pipeline),                            "💰", new Color(250, 130, 40)));

        // ── Lower panels ─────────────────────────────────
        JPanel lowerRow = new JPanel(new GridLayout(1, 2, 16, 0));
        lowerRow.setBackground(UITheme.BG_DARK);
        lowerRow.add(buildQuickStats());
        lowerRow.add(buildTipsPanel());

        // ── Assemble ─────────────────────────────────────
        JPanel content = new JPanel();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBackground(UITheme.BG_DARK);
        content.setBorder(BorderFactory.createEmptyBorder(24, 24, 24, 24));
        content.add(topBar);
        content.add(kpiRow);
        content.add(kpiRow2);
        content.add(lowerRow);

        add(content, BorderLayout.CENTER);
        revalidate();
        repaint();
    }

    private JPanel kpiCard(String title, String value, String icon, Color accent) {
        JPanel card = new JPanel(new BorderLayout(0, 8));
        card.setBackground(UITheme.BG_CARD);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(UITheme.BORDER_COLOR, 1),
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));

        JPanel topRow = new JPanel(new BorderLayout());
        topRow.setBackground(UITheme.BG_CARD);

        JLabel iconLbl = new JLabel(icon);
        iconLbl.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 24));

        // Coloured accent line at top
        JPanel accentLine = new JPanel();
        accentLine.setPreferredSize(new Dimension(0, 3));
        accentLine.setBackground(accent);

        JLabel titleLbl = UITheme.muted(title);
        JLabel valueLbl = new JLabel(value);
        valueLbl.setFont(new Font("Segoe UI", Font.BOLD, 28));
        valueLbl.setForeground(accent);

        topRow.add(iconLbl, BorderLayout.WEST);
        topRow.add(titleLbl, BorderLayout.CENTER);

        card.add(accentLine, BorderLayout.NORTH);
        card.add(topRow, BorderLayout.CENTER);
        card.add(valueLbl, BorderLayout.SOUTH);
        return card;
    }

    private JPanel buildQuickStats() {
        JPanel card = UITheme.card();
        card.setLayout(new BorderLayout(0, 12));

        JLabel hdr = UITheme.headerLabel("📊  Quick Statistics");
        hdr.setBorder(BorderFactory.createEmptyBorder(0, 0, 8, 0));

        JPanel rows = new JPanel(new GridLayout(0, 1, 0, 8));
        rows.setBackground(UITheme.BG_CARD);
        rows.add(statRow("Resolved Tickets",  String.valueOf(ticketDAO.getResolvedTickets()),  UITheme.ACCENT_GREEN));
        rows.add(statRow("Today's Interactions",String.valueOf(interactionDAO.getTodayInteractions()), UITheme.ACCENT));
        rows.add(statRow("Corporate Customers", String.valueOf(corpCount()), UITheme.ACCENT_PURPLE));
        rows.add(statRow("Inactive Accounts",   String.valueOf(inactiveCount()), UITheme.ACCENT_RED));

        card.add(hdr, BorderLayout.NORTH);
        card.add(rows, BorderLayout.CENTER);
        return card;
    }

    private JPanel statRow(String label, String value, Color color) {
        JPanel row = new JPanel(new BorderLayout());
        row.setBackground(UITheme.BG_CARD);
        row.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 3, 0, 0, color),
            BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));
        JLabel lbl = new JLabel(label);
        lbl.setFont(UITheme.FONT_BODY);
        lbl.setForeground(UITheme.TEXT_PRIMARY);
        JLabel val = new JLabel(value);
        val.setFont(UITheme.FONT_HEADING);
        val.setForeground(color);
        row.add(lbl, BorderLayout.WEST);
        row.add(val, BorderLayout.EAST);
        return row;
    }

    private JPanel buildTipsPanel() {
        JPanel card = UITheme.card();
        card.setLayout(new BorderLayout(0, 12));

        JLabel hdr = UITheme.headerLabel("💡  Getting Started");
        hdr.setBorder(BorderFactory.createEmptyBorder(0, 0, 8, 0));

        String[] tips = {
            "→  Use the Customers tab to manage all contacts",
            "→  Log every call, email or meeting in Interactions",
            "→  Raise a Service Ticket for support requests",
            "→  Track sales in the Deals / Pipeline section",
            "→  Use search to instantly find any customer",
            "→  Click a row to view full customer details",
        };
        JPanel tipsPanel = new JPanel(new GridLayout(0, 1, 0, 6));
        tipsPanel.setBackground(UITheme.BG_CARD);
        for (String tip : tips) {
            JLabel l = new JLabel(tip);
            l.setFont(UITheme.FONT_BODY);
            l.setForeground(UITheme.TEXT_MUTED);
            tipsPanel.add(l);
        }

        card.add(hdr, BorderLayout.NORTH);
        card.add(tipsPanel, BorderLayout.CENTER);
        return card;
    }

    public void refresh() { build(); }

    // ── Helpers ────────────────────────────────────────
    private String formatLakh(double val) {
        if (val >= 100000) return String.format("%.1fL", val / 100000);
        return String.format("%.0f", val);
    }

    private int corpCount() {
        return new CustomerDAO().getAllCustomers().stream()
            .filter(c -> "Corporate".equals(c.getCustomerType())).mapToInt(e -> 1).sum();
    }
    private int inactiveCount() {
        return new CustomerDAO().getAllCustomers().stream()
            .filter(c -> "Inactive".equals(c.getStatus())).mapToInt(e -> 1).sum();
    }
}
