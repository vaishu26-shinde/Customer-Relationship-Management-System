package com.crm;

import com.crm.ui.MainWindow;
import com.crm.util.DatabaseConnection;
import com.crm.util.UITheme;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;


public class Main {

    public static void main(String[] args) {
        UITheme.apply();

        SwingUtilities.invokeLater(() -> {
            // ── Splash screen ────────────────────────────
            JWindow splash = buildSplash();
            splash.setVisible(true);

            // ── Test DB connection ───────────────────────
            Timer timer = new Timer(2200, e -> {
                splash.dispose();
                Connection conn = DatabaseConnection.getInstance().getConnection();
                if (conn == null) {
                    JOptionPane.showMessageDialog(null,
                        "<html><b>Database connection failed.</b><br>" +
                        "Please check:<br>" +
                        "• MySQL is running<br>" +
                        "• Password in DatabaseConnection.java is correct<br>" +
                        "• crm_schema.sql has been executed</html>",
                        "Connection Error", JOptionPane.ERROR_MESSAGE);
                    System.exit(1);
                }
                new MainWindow();
            });
            timer.setRepeats(false);
            timer.start();
        });
    }

    private static JWindow buildSplash() {
        JWindow w = new JWindow();
        w.setSize(460, 260);
        w.setLocationRelativeTo(null);

        JPanel panel = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, new Color(13,17,30), getWidth(), getHeight(), new Color(22,35,70));
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
                // decorative circles
                g2.setColor(new Color(56,139,255,30));
                g2.fillOval(-40, -40, 200, 200);
                g2.fillOval(300, 120, 180, 180);
            }
        };
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createLineBorder(UITheme.BORDER_COLOR, 1));

        JPanel center = new JPanel();
        center.setLayout(new BoxLayout(center, BoxLayout.Y_AXIS));
        center.setOpaque(false);
        center.setBorder(BorderFactory.createEmptyBorder(40, 50, 20, 50));

        JLabel icon = new JLabel("◈");
        icon.setFont(new Font("Segoe UI", Font.BOLD, 48));
        icon.setForeground(UITheme.ACCENT);
        icon.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel title = new JLabel("CRM Pro");
        title.setFont(new Font("Segoe UI", Font.BOLD, 32));
        title.setForeground(UITheme.TEXT_PRIMARY);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel sub = new JLabel("Customer Relationship Management");
        sub.setFont(UITheme.FONT_BODY);
        sub.setForeground(UITheme.TEXT_MUTED);
        sub.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel loading = new JLabel("Connecting to database...");
        loading.setFont(UITheme.FONT_SMALL);
        loading.setForeground(UITheme.ACCENT);
        loading.setAlignmentX(Component.CENTER_ALIGNMENT);

        center.add(icon);
        center.add(Box.createVerticalStrut(8));
        center.add(title);
        center.add(Box.createVerticalStrut(6));
        center.add(sub);
        center.add(Box.createVerticalStrut(20));
        center.add(loading);

        panel.add(center, BorderLayout.CENTER);

        JLabel footer = new JLabel("  BTech Project 2026  •  Java + MySQL", SwingConstants.CENTER);
        footer.setFont(UITheme.FONT_SMALL);
        footer.setForeground(UITheme.TEXT_MUTED);
        footer.setBorder(BorderFactory.createEmptyBorder(0, 0, 12, 0));
        panel.add(footer, BorderLayout.SOUTH);

        w.setContentPane(panel);
        return w;
    }
}
