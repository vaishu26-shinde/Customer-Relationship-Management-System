package com.crm.model;

import java.sql.Timestamp;
import java.sql.Date;

public class Interaction {
    private int interactionId, customerId;
    private String interactionType, subject, description, outcome;
    private Timestamp interactionDate;
    private Date nextFollowUp;
    private String createdBy, customerName;

    public Interaction() { this.createdBy = "Admin"; }

    // ── Getters & Setters ──────────────────────────────
    public int getInteractionId()                  { return interactionId; }
    public void setInteractionId(int v)            { this.interactionId = v; }

    public int getCustomerId()                     { return customerId; }
    public void setCustomerId(int v)               { this.customerId = v; }

    public String getInteractionType()             { return interactionType; }
    public void setInteractionType(String v)       { this.interactionType = v; }

    public String getSubject()                     { return subject; }
    public void setSubject(String v)               { this.subject = v; }

    public String getDescription()                 { return description; }
    public void setDescription(String v)           { this.description = v; }

    public String getOutcome()                     { return outcome; }
    public void setOutcome(String v)               { this.outcome = v; }

    public Timestamp getInteractionDate()          { return interactionDate; }
    public void setInteractionDate(Timestamp v)    { this.interactionDate = v; }

    public Date getNextFollowUp()                  { return nextFollowUp; }
    public void setNextFollowUp(Date v)            { this.nextFollowUp = v; }

    public String getCreatedBy()                   { return createdBy; }
    public void setCreatedBy(String v)             { this.createdBy = v; }

    public String getCustomerName()                { return customerName; }
    public void setCustomerName(String v)          { this.customerName = v; }
}
