package com.crm.model;

import java.sql.Timestamp;

public class Customer {
    private int customerId;
    private String firstName, lastName, email, phone;
    private String company, address, city, state, country;
    private String customerType, status, notes;
    private Timestamp createdAt, updatedAt;

    public Customer() { this.country = "India"; }

    public Customer(String firstName, String lastName, String email, String phone,
                    String company, String city, String state, String customerType, String status) {
        this.firstName = firstName; this.lastName = lastName;
        this.email = email;         this.phone = phone;
        this.company = company;     this.city = city;
        this.state = state;         this.customerType = customerType;
        this.status = status;       this.country = "India";
    }

    // ── Getters & Setters ──────────────────────────────
    public int getCustomerId()             { return customerId; }
    public void setCustomerId(int id)      { this.customerId = id; }

    public String getFirstName()           { return firstName; }
    public void setFirstName(String v)     { this.firstName = v; }

    public String getLastName()            { return lastName; }
    public void setLastName(String v)      { this.lastName = v; }

    public String getFullName()            { return firstName + " " + lastName; }

    public String getEmail()               { return email; }
    public void setEmail(String v)         { this.email = v; }

    public String getPhone()               { return phone; }
    public void setPhone(String v)         { this.phone = v; }

    public String getCompany()             { return company; }
    public void setCompany(String v)       { this.company = v; }

    public String getAddress()             { return address; }
    public void setAddress(String v)       { this.address = v; }

    public String getCity()                { return city; }
    public void setCity(String v)          { this.city = v; }

    public String getState()               { return state; }
    public void setState(String v)         { this.state = v; }

    public String getCountry()             { return country; }
    public void setCountry(String v)       { this.country = v; }

    public String getCustomerType()        { return customerType; }
    public void setCustomerType(String v)  { this.customerType = v; }

    public String getStatus()              { return status; }
    public void setStatus(String v)        { this.status = v; }

    public String getNotes()               { return notes; }
    public void setNotes(String v)         { this.notes = v; }

    public Timestamp getCreatedAt()        { return createdAt; }
    public void setCreatedAt(Timestamp v)  { this.createdAt = v; }

    public Timestamp getUpdatedAt()        { return updatedAt; }
    public void setUpdatedAt(Timestamp v)  { this.updatedAt = v; }

    @Override public String toString()     { return getFullName() + " <" + email + ">"; }
}
