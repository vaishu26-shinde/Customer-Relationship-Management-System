package com.crm.model;

import java.sql.Date;
import java.sql.Timestamp;

public class Deal {
    private int dealId, customerId, probability;
    private String dealName, stage, notes, customerName;
    private double value;
    private Date closeDate;
    private Timestamp createdAt;

    public Deal() {}

    public int getDealId()                 { return dealId; }
    public void setDealId(int v)           { this.dealId = v; }

    public int getCustomerId()             { return customerId; }
    public void setCustomerId(int v)       { this.customerId = v; }

    public String getDealName()            { return dealName; }
    public void setDealName(String v)      { this.dealName = v; }

    public double getValue()               { return value; }
    public void setValue(double v)         { this.value = v; }

    public String getStage()               { return stage; }
    public void setStage(String v)         { this.stage = v; }

    public int getProbability()            { return probability; }
    public void setProbability(int v)      { this.probability = v; }

    public String getNotes()               { return notes; }
    public void setNotes(String v)         { this.notes = v; }

    public String getCustomerName()        { return customerName; }
    public void setCustomerName(String v)  { this.customerName = v; }

    public Date getCloseDate()             { return closeDate; }
    public void setCloseDate(Date v)       { this.closeDate = v; }

    public Timestamp getCreatedAt()        { return createdAt; }
    public void setCreatedAt(Timestamp v)  { this.createdAt = v; }
}
