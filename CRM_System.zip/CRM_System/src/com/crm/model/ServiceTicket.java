package com.crm.model;

import java.sql.Timestamp;

public class ServiceTicket {
    private int serviceId, customerId;
    private String serviceType, description, status, priority;
    private String ticketNumber, assignedTo, resolution, customerName;
    private Timestamp serviceDate, resolvedDate;

    public ServiceTicket() {}

    // ── Getters & Setters ──────────────────────────────
    public int getServiceId()                    { return serviceId; }
    public void setServiceId(int v)              { this.serviceId = v; }

    public int getCustomerId()                   { return customerId; }
    public void setCustomerId(int v)             { this.customerId = v; }

    public String getServiceType()               { return serviceType; }
    public void setServiceType(String v)         { this.serviceType = v; }

    public String getDescription()               { return description; }
    public void setDescription(String v)         { this.description = v; }

    public String getStatus()                    { return status; }
    public void setStatus(String v)              { this.status = v; }

    public String getPriority()                  { return priority; }
    public void setPriority(String v)            { this.priority = v; }

    public String getTicketNumber()              { return ticketNumber; }
    public void setTicketNumber(String v)        { this.ticketNumber = v; }

    public String getAssignedTo()                { return assignedTo; }
    public void setAssignedTo(String v)          { this.assignedTo = v; }

    public String getResolution()                { return resolution; }
    public void setResolution(String v)          { this.resolution = v; }

    public String getCustomerName()              { return customerName; }
    public void setCustomerName(String v)        { this.customerName = v; }

    public Timestamp getServiceDate()            { return serviceDate; }
    public void setServiceDate(Timestamp v)      { this.serviceDate = v; }

    public Timestamp getResolvedDate()           { return resolvedDate; }
    public void setResolvedDate(Timestamp v)     { this.resolvedDate = v; }
}
