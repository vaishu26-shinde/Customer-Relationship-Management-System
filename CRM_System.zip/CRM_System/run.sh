#!/bin/bash
echo "============================================"
echo "  CRM Pro - Compiling and Running..."
echo "============================================"

JAVA_SRC="src"
OUT_DIR="out"
LIB="lib/mysql-connector-java-8.0.33.jar"

mkdir -p $OUT_DIR

echo "[1/2] Compiling Java sources..."
javac -cp "$LIB" -d "$OUT_DIR" -sourcepath "$JAVA_SRC" "$JAVA_SRC/com/crm/Main.java"

if [ $? -ne 0 ]; then
    echo "[ERROR] Compilation failed."
    exit 1
fi

echo "[2/2] Launching CRM Pro..."
java -cp "$OUT_DIR:$LIB" com.crm.Main
